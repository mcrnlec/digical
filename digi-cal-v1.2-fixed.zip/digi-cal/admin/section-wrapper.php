<?php
if (!function_exists('digical_section_wrapper')) {
    function digical_section_wrapper($active, $content_html) {
        global $wpdb;

        // Menus
        $menu_items = [
            'General'  => 'digical',
            'Days'     => 'digical-days',
            'Venues'   => 'digical-venues',
            'Speakers' => 'digical-speakers',
        ];
        $current_page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';

        // Fetch days from DB (not CSV)
        $table = $wpdb->prefix . 'digical_days';
        $days = $wpdb->get_results("
            SELECT id, date
            FROM `$table`
            ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC
        ", ARRAY_A) ?: [];

        // Label helper
        $label = function($raw) {
            $t = preg_replace('/\D+/', '', (string)$raw);
            return preg_match('/^(\d{2})(\d{2})(\d{4})$/', $t, $m) ? "{$m[1]}.{$m[2]}.{$m[3]}" : esc_html($raw);
        };

        echo '<style>
            .digical-flex-container{display:flex;margin-top:20px;min-height:70vh}
            .digical-sidebar{box-sizing:border-box;width:15%;min-width:140px;background:#f7f7f7;border-radius:6px;box-shadow:0 0 0 1px #e1e1e1;padding:24px 8px;display:flex;flex-direction:column;overflow:hidden}
            .digical-sidebar ul{list-style:none;margin:0;padding-left:0}
            .digical-sidebar li{margin-bottom:6px}
            .digical-link{display:block;padding:7px 14px;border-radius:4px;color:#23282d;text-decoration:none;transition:background .25s;box-sizing:border-box}
            .digical-link.active,.digical-link:hover{background:#007cba;color:#fff;font-weight:500}
            .digical-content-area{width:75%;margin-left:24px}
            .digical-days-row{display:flex;align-items:center;gap:6px;width:100%;box-sizing:border-box}
            .digical-days-row .digical-link{flex:0 0 calc(85% - 6px);min-width:0}
            .digical-days-toggle{flex:0 0 15%;min-width:40px;text-align:center;background:#f6f7f7;border:1px solid #c3c4c7;border-radius:4px;padding:6px 0;cursor:pointer;line-height:1;box-sizing:border-box}
            .digical-days-toggle:hover{background:#eef0f1}
            .digical-days-toggle .caret{display:inline-block;transition:transform .18s ease;font-size:14px}
            .digical-days-toggle[aria-expanded="false"] .caret{transform:rotate(-90deg)}
            .digical-days-sublist{margin:8px 0 0 0}
            .digical-days-sublist li{margin:4px 0}
            .digical-days-sublist a,
            .digical-days-sublist a:link,
            .digical-days-sublist a:visited,
            .digical-days-sublist a:hover,
            .digical-days-sublist a:active{
                display:block;
                padding:5px 14px 5px 40px;
                color:#23282d !important;
                text-decoration:none !important;
                background:transparent !important;
                font-weight:400 !important;
                border-radius:0 !important;
                box-shadow:none !important;
            }
            .is-hidden{display:none}
        </style>';

        echo '<div class="digical-flex-container">
            <nav class="digical-sidebar">
                <ul>';

        foreach ($menu_items as $labelTxt => $slug) {
            echo '<li>';
            if ($labelTxt !== 'Days') {
                $url = admin_url('admin.php?page='.$slug);
                $active_class = ($current_page === $slug) ? 'active' : '';
                echo '<a href="'.esc_url($url).'" class="digical-link '.$active_class.'">'.esc_html($labelTxt).'</a>';
            } else {
                $days_url  = admin_url('admin.php?page=digical-days');
                $is_active = ($current_page === 'digical-days') ? 'active' : '';
                echo '<div class="digical-days-row">';
                echo    '<a href="'.esc_url($days_url).'" class="digical-link '.$is_active.'">'.esc_html__('Days','digical').'</a>';
                echo    '<button type="button" class="digical-days-toggle" data-target="#digical-days-list" aria-expanded="true" aria-controls="digical-days-list"><span class="caret">▾</span></button>';
                echo '</div>';

                echo '<ul id="digical-days-list" class="digical-days-sublist">';
                foreach ($days as $d) {
                    $day_slug  = 'digical-day-'.$d['id']; // use id for slug
                    $day_url   = admin_url('admin.php?page='.$day_slug);
                    echo '<li><a href="'.esc_url($day_url).'" class="digical-link">'.esc_html($label($d['date'])).'</a></li>';
                }
                echo '</ul>';
            }
            echo '</li>';
        }

        echo '   </ul>
            </nav>
            <div class="digical-content-area">'.$content_html.'</div>
        </div>';

        echo '<script>
        (function(){
          const btn  = document.querySelector(".digical-days-toggle[data-target=\"#digical-days-list\"]");
          const list = document.getElementById("digical-days-list");
          if(!btn || !list) return;
          const KEY = "digical_days_collapsed";
          if(localStorage.getItem(KEY) === "1"){
            list.classList.add("is-hidden");
            btn.setAttribute("aria-expanded","false");
          } else {
            btn.setAttribute("aria-expanded","true");
          }
          btn.addEventListener("click", function(ev){
            ev.preventDefault();
            ev.stopPropagation();
            const open = btn.getAttribute("aria-expanded") === "true";
            btn.setAttribute("aria-expanded", open ? "false" : "true");
            list.classList.toggle("is-hidden", open);
            localStorage.setItem(KEY, open ? "1" : "0");
          }, {passive:false});
        })();
        </script>';
    }
}
?>
