<?php
if (!defined('ABSPATH')) exit;

/**
 * DigiCal — Configuration: Titles & Roles Management
 * Admin UI for managing speaker titles and roles
 */

global $wpdb;

// Get initial data
$titles = function_exists('digical_titles_all_rows') ? digical_titles_all_rows() : [];
$roles = function_exists('digical_roles_all_rows') ? digical_roles_all_rows() : [];

$nonce = wp_create_nonce('digical_config_nonce');
$ajaxurl = admin_url('admin-ajax.php');
?>

<style>
.digical-config-wrapper {
    display: flex;
    gap: 30px;
    margin-top: 20px;
}

.digical-config-section {
    flex: 1;
    min-width: 400px;
}

.digical-config-section h2 {
    border-bottom: 3px solid #0076bf;
    padding-bottom: 10px;
    margin-bottom: 20px;
    color: #0076bf;
}

.digical-config-form {
    background: #f9f9f9;
    padding: 16px;
    border-radius: 4px;
    border: 1px solid #ddd;
    margin-bottom: 20px;
}

.digical-config-form input {
    width: 100%;
    padding: 8px 12px;
    font-size: 14px;
    margin-bottom: 10px;
    box-sizing: border-box;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.digical-config-form button {
    background: #0076bf;
    color: #fff;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: 600;
    transition: background 0.2s;
}

.digical-config-form button:hover {
    background: #005a87;
}

.digical-config-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    margin-top: 10px;
}

.digical-config-table th,
.digical-config-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.digical-config-table th {
    background: #0076bf;
    color: #fff;
    font-weight: 600;
    text-align: center;
}

.digical-config-table td {
    vertical-align: middle;
}

.digical-config-table tr:hover {
    background: #f5f5f5;
}

.digical-config-table td.actions {
    text-align: center;
    white-space: nowrap;
}

.digical-btn-small {
    background: #1675bb;
    color: #fff;
    border: none;
    padding: 5px 10px;
    margin-right: 5px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
    transition: background 0.2s;
}

.digical-btn-small:hover {
    background: #145e90;
}

.digical-btn-small.delete {
    background: #e53935;
}

.digical-btn-small.delete:hover {
    background: #b71c1c;
}

.digical-edit-input {
    width: 90%;
    padding: 6px 8px;
    border: 1px solid #0076bf;
    border-radius: 3px;
    font-size: 14px;
}

.digical-message {
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 4px;
    display: none;
}

.digical-message.success {
    background: #c6e1b9;
    color: #2d6b0f;
    border: 1px solid #5ba618;
}

.digical-message.error {
    background: #f8e5e1;
    color: #8a2e2b;
    border: 1px solid #d97a72;
}

.digical-message.show {
    display: block;
}

@media (max-width: 1000px) {
    .digical-config-wrapper {
        flex-direction: column;
    }
    
    .digical-config-section {
        min-width: 100%;
    }
}
</style>

<h1>Speaker Configuration</h1>
<p>Manage speaker titles and roles that will be used throughout the system.</p>

<div class="digical-config-wrapper">
    <!-- Titles Section -->
    <div class="digical-config-section">
        <h2>Titles</h2>
        <p style="color: #666; font-size: 13px; margin-bottom: 15px;">
            Define titles like "Dr.", "Prof.", "Mr.", etc. that speakers can have.
        </p>
        
        <div id="titles-message" class="digical-message"></div>
        
        <div class="digical-config-form">
            <input 
                type="text" 
                id="title_input" 
                placeholder="e.g., Dr., Prof., Mr., Mrs., Ms."
                autocomplete="off"
            >
            <button type="button" id="add_title_btn">Add Title</button>
        </div>
        
        <table class="digical-config-table" id="titles_table">
            <thead>
                <tr>
                    <th style="text-align: left;">Title</th>
                    <th style="width: 120px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($titles as $title): ?>
                    <tr data-id="<?php echo esc_attr($title['id']); ?>">
                        <td class="title-text"><?php echo esc_html($title['title']); ?></td>
                        <td class="actions">
                            <button type="button" class="digical-btn-small edit-title">Edit</button>
                            <button type="button" class="digical-btn-small delete delete-title">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Roles Section -->
    <div class="digical-config-section">
        <h2>Roles</h2>
        <p style="color: #666; font-size: 13px; margin-bottom: 15px;">
            Define roles like "Speaker", "Moderator", "Panelist", etc.
        </p>
        
        <div id="roles-message" class="digical-message"></div>
        
        <div class="digical-config-form">
            <input 
                type="text" 
                id="role_input" 
                placeholder="e.g., Speaker, Moderator, Panelist"
                autocomplete="off"
            >
            <button type="button" id="add_role_btn">Add Role</button>
        </div>
        
        <table class="digical-config-table" id="roles_table">
            <thead>
                <tr>
                    <th style="text-align: left;">Role</th>
                    <th style="width: 120px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($roles as $role): ?>
                    <tr data-id="<?php echo esc_attr($role['id']); ?>">
                        <td class="role-text"><?php echo esc_html($role['role']); ?></td>
                        <td class="actions">
                            <button type="button" class="digical-btn-small edit-role">Edit</button>
                            <button type="button" class="digical-btn-small delete delete-role">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
(function() {
    const ajaxurl = <?php echo json_encode($ajaxurl); ?>;
    
    // Helper: Show message
    function showMessage(elementId, type, text) {
        const $msg = document.getElementById(elementId);
        if (!$msg) return;
        $msg.className = 'digical-message ' + type + ' show';
        $msg.textContent = text;
        setTimeout(() => {
            $msg.classList.remove('show');
        }, 4000);
    }
    
    // Helper: Make AJAX request
    async function ajaxPost(action, data) {
        try {
            const payload = new URLSearchParams({ action, ...data }).toString();
            const res = await fetch(ajaxurl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: payload
            });
            const txt = await res.text();
            try { return JSON.parse(txt); } catch(e) { console.warn('Non-JSON response:', txt); return null; }
        } catch(err) { console.error(err); return null; }
    }
    
    // ===== TITLES MANAGEMENT =====
    
    function renderTitles(titles) {
        const $tbody = document.querySelector('#titles_table tbody');
        if (!Array.isArray(titles)) return;
        
        $tbody.innerHTML = '';
        titles.forEach(title => {
            const tr = document.createElement('tr');
            tr.setAttribute('data-id', title.id);
            tr.innerHTML = `
                <td class="title-text">${escapeHtml(title.title)}</td>
                <td class="actions">
                    <button type="button" class="digical-btn-small edit-title">Edit</button>
                    <button type="button" class="digical-btn-small delete delete-title">Delete</button>
                </td>
            `;
            $tbody.appendChild(tr);
        });
    }
    
    // Add title
    document.getElementById('add_title_btn').addEventListener('click', async () => {
        const val = document.getElementById('title_input').value.trim();
        if (!val) {
            showMessage('titles-message', 'error', 'Please enter a title.');
            return;
        }
        
        const resp = await ajaxPost('digical_add_title', { title: val });
        if (resp && resp.success) {
            document.getElementById('title_input').value = '';
            renderTitles(resp.data.titles);
            showMessage('titles-message', 'success', 'Title added successfully!');
        } else {
            showMessage('titles-message', 'error', (resp && resp.data && resp.data.message) || 'Error adding title');
        }
    });
    
    // Edit/Delete titles
    document.getElementById('titles_table').addEventListener('click', async (e) => {
        const btn = e.target.closest('button');
        if (!btn) return;
        
        const tr = btn.closest('tr');
        const id = tr.getAttribute('data-id');
        const $text = tr.querySelector('.title-text');
        
        if (btn.classList.contains('edit-title')) {
            const current = $text.textContent.trim();
            $text.innerHTML = `<input type="text" class="digical-edit-input" value="${escapeHtml(current)}">`;
            btn.textContent = 'Save';
            btn.classList.remove('edit-title');
            btn.classList.add('save-title');
            return;
        }
        
        if (btn.classList.contains('save-title')) {
            const newVal = $text.querySelector('input').value.trim();
            if (!newVal) {
                showMessage('titles-message', 'error', 'Title cannot be empty.');
                return;
            }
            
            const resp = await ajaxPost('digical_edit_title', { id, title: newVal });
            if (resp && resp.success) {
                renderTitles(resp.data.titles);
                showMessage('titles-message', 'success', 'Title updated successfully!');
            } else {
                showMessage('titles-message', 'error', (resp && resp.data && resp.data.message) || 'Error updating title');
            }
            return;
        }
        
        if (btn.classList.contains('delete-title')) {
            if (!confirm('Delete this title?')) return;
            
            const resp = await ajaxPost('digical_delete_title', { id });
            if (resp && resp.success) {
                renderTitles(resp.data.titles);
                showMessage('titles-message', 'success', 'Title deleted successfully!');
            } else {
                showMessage('titles-message', 'error', (resp && resp.data && resp.data.message) || 'Error deleting title');
            }
            return;
        }
    });
    
    // Enter key on title input
    document.getElementById('title_input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            document.getElementById('add_title_btn').click();
        }
    });
    
    // ===== ROLES MANAGEMENT =====
    
    function renderRoles(roles) {
        const $tbody = document.querySelector('#roles_table tbody');
        if (!Array.isArray(roles)) return;
        
        $tbody.innerHTML = '';
        roles.forEach(role => {
            const tr = document.createElement('tr');
            tr.setAttribute('data-id', role.id);
            tr.innerHTML = `
                <td class="role-text">${escapeHtml(role.role)}</td>
                <td class="actions">
                    <button type="button" class="digical-btn-small edit-role">Edit</button>
                    <button type="button" class="digical-btn-small delete delete-role">Delete</button>
                </td>
            `;
            $tbody.appendChild(tr);
        });
    }
    
    // Add role
    document.getElementById('add_role_btn').addEventListener('click', async () => {
        const val = document.getElementById('role_input').value.trim();
        if (!val) {
            showMessage('roles-message', 'error', 'Please enter a role.');
            return;
        }
        
        const resp = await ajaxPost('digical_add_role', { role: val });
        if (resp && resp.success) {
            document.getElementById('role_input').value = '';
            renderRoles(resp.data.roles);
            showMessage('roles-message', 'success', 'Role added successfully!');
        } else {
            showMessage('roles-message', 'error', (resp && resp.data && resp.data.message) || 'Error adding role');
        }
    });
    
    // Edit/Delete roles
    document.getElementById('roles_table').addEventListener('click', async (e) => {
        const btn = e.target.closest('button');
        if (!btn) return;
        
        const tr = btn.closest('tr');
        const id = tr.getAttribute('data-id');
        const $text = tr.querySelector('.role-text');
        
        if (btn.classList.contains('edit-role')) {
            const current = $text.textContent.trim();
            $text.innerHTML = `<input type="text" class="digical-edit-input" value="${escapeHtml(current)}">`;
            btn.textContent = 'Save';
            btn.classList.remove('edit-role');
            btn.classList.add('save-role');
            return;
        }
        
        if (btn.classList.contains('save-role')) {
            const newVal = $text.querySelector('input').value.trim();
            if (!newVal) {
                showMessage('roles-message', 'error', 'Role cannot be empty.');
                return;
            }
            
            const resp = await ajaxPost('digical_edit_role', { id, role: newVal });
            if (resp && resp.success) {
                renderRoles(resp.data.roles);
                showMessage('roles-message', 'success', 'Role updated successfully!');
            } else {
                showMessage('roles-message', 'error', (resp && resp.data && resp.data.message) || 'Error updating role');
            }
            return;
        }
        
        if (btn.classList.contains('delete-role')) {
            if (!confirm('Delete this role?')) return;
            
            const resp = await ajaxPost('digical_delete_role', { id });
            if (resp && resp.success) {
                renderRoles(resp.data.roles);
                showMessage('roles-message', 'success', 'Role deleted successfully!');
            } else {
                showMessage('roles-message', 'error', (resp && resp.data && resp.data.message) || 'Error deleting role');
            }
            return;
        }
    });
    
    // Enter key on role input
    document.getElementById('role_input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            document.getElementById('add_role_btn').click();
        }
    });
    
    // Helper: Escape HTML
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
})();
</script>
