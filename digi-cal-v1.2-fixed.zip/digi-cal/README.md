# DigiCal - Conference Calendar Management Plugin

A professional, scalable WordPress plugin for managing conference and event calendars with complete backend admin tools, speaker/venue management, and public-facing calendar views.

## ✨ Features

### Core Features
- **Days Management** - Create, edit, delete conference days with time ranges
- **Venues Management** - Manage venues with hierarchical parent/child relationships
- **Speaker Configuration** - Define speaker titles and roles
- **Professional Admin UI** - Clean, responsive admin interface with sidebar
- **Database-Backed** - All data stored in WordPress database (not CSV files)
- **Real-time Updates** - No page reloads needed for CRUD operations
- **Automatic Updates** - GitHub-based automatic updates

### Security
- Admin-only access (manage_options capability)
- Input sanitization and validation
- SQL injection prevention (prepared statements)
- XSS protection (HTML escaping)
- CSRF protection via WordPress capabilities

### Performance
- Indexed database queries
- Transient caching for GitHub release info
- Efficient AJAX endpoints
- Optimized database tables

## 🚀 Installation

### Method 1: Upload ZIP (Easiest)

1. Go to **Plugins > Add New > Upload Plugin**
2. Download latest `digi-cal-v*.zip` from [Releases](../../releases)
3. Upload and activate

### Method 2: WordPress Plugin Directory (When Available)

1. Go to **Plugins > Add New**
2. Search for "DigiCal"
3. Click "Install Now" and "Activate"

### Requirements
- WordPress 5.0+
- PHP 7.0+
- MySQL 5.6+ or MariaDB 10.1+

## 📖 Quick Start

### Initial Setup (5 minutes)

1. **Go to Configuration**
   - DigiCal > Speakers > Configuration

2. **Add Speaker Titles**
   - Enter titles: Dr., Prof., Mr., Mrs., Ms., Eng., etc.
   - Press Enter or click "Add Title"

3. **Add Speaker Roles**
   - Enter roles: Speaker, Moderator, Panelist, Organizer, etc.
   - Press Enter or click "Add Role"

4. **Manage Days**
   - Go to DigiCal > Days
   - Add conference dates with time ranges

5. **Manage Venues**
   - Go to DigiCal > Venues
   - Add venues with optional parent-child relationships

## 📁 Menu Structure

```
WordPress Admin > DigiCal
├── General              → General settings
├── Days                 → Manage conference days
├── Venues               → Manage venues
└── Speakers
    ├── Speakers         → Manage speakers (coming soon)
    └── Configuration    → Manage titles & roles
```

## 🗄️ Database Tables

| Table | Purpose |
|-------|---------|
| `wp_digical_days` | Conference days with times |
| `wp_digical_venues` | Venues with hierarchies |
| `wp_digical_titles` | Speaker titles |
| `wp_digical_roles` | Speaker roles |
| `wp_digical_speakers_roles` | Speaker-role relationships |

All tables created automatically on plugin activation.

## 🔌 API Reference

### Days Management

```php
// Get all days (sorted chronologically)
$days = digical_days_all_rows();

// Add a new day
$day_id = digical_days_insert_row(
    '01102025',  // Date in DDMMYYYY format
    '08:00',     // Start time HH:MM
    '17:00'      // End time HH:MM
);

// Update a day
digical_days_update_row($day_id, '01102025', '09:00', '18:00');

// Delete a day
digical_days_delete_row($day_id);
```

### Venues Management

```php
// Get all venues (with hierarchies)
$venues = digical_venues_all_rows();

// Add a primary venue
$venue_id = digical_venues_insert_row(
    'primary',           // Type: 'primary' or 'secondary'
    'Main Hall',        // Venue name
    '123 Main St'       // Address
);

// Add a sub-venue
$sub_venue_id = digical_venues_insert_row(
    'secondary',
    'Room A',
    '123 Main St',
    $venue_id  // Parent ID
);

// Update a venue
digical_venues_update_row($venue_id, 'primary', 'Main Hall Updated', '123 Main St');

// Delete a venue
digical_venues_delete_row($venue_id);
```

### Titles Management

```php
// Get all titles
$titles = digical_titles_all_rows();

// Add a title
$title_id = digical_titles_insert_row('Dr.');

// Update a title
digical_titles_update_row($title_id, 'Professor');

// Delete a title
digical_titles_delete_row($title_id);
```

### Roles Management

```php
// Get all roles
$roles = digical_roles_all_rows();

// Add a role
$role_id = digical_roles_insert_row('Speaker');

// Update a role
digical_roles_update_row($role_id, 'Keynote Speaker');

// Delete a role
digical_roles_delete_row($role_id);
```

### Speaker-Roles Relationships

```php
// Link a speaker to a role
digical_speaker_roles_add('speaker_uuid', 'role_uuid');

// Get all roles for a speaker
$role_ids = digical_speaker_roles_get('speaker_uuid');

// Unlink a speaker from a role
digical_speaker_roles_remove('speaker_uuid', 'role_uuid');
```

## 🌐 AJAX Endpoints

All endpoints require `manage_options` capability.

### Days Endpoints

```javascript
// Get all days
fetch('/wp-admin/admin-ajax.php', {
  method: 'POST',
  body: new URLSearchParams({
    action: 'digical_db_get_days'
  })
});

// Add day
fetch('/wp-admin/admin-ajax.php', {
  method: 'POST',
  body: new URLSearchParams({
    action: 'digical_db_add_day',
    day_date: '01102025',
    start_time: '08:00',
    end_time: '17:00'
  })
});

// Edit day
fetch('/wp-admin/admin-ajax.php', {
  method: 'POST',
  body: new URLSearchParams({
    action: 'digical_db_edit_day',
    id: 'day_uuid',
    day_date: '01102025',
    start_time: '09:00',
    end_time: '18:00'
  })
});

// Delete day
fetch('/wp-admin/admin-ajax.php', {
  method: 'POST',
  body: new URLSearchParams({
    action: 'digical_db_delete_day',
    id: 'day_uuid'
  })
});

// Bulk delete days
fetch('/wp-admin/admin-ajax.php', {
  method: 'POST',
  body: new URLSearchParams({
    action: 'digical_db_delete_days',
    ids: 'id1,id2,id3'  // Comma-separated or array
  })
});
```

### Venues Endpoints

Similar pattern to Days - replace `digical_db_*_day` with `digical_db_*_venue` and adjust parameters.

### Titles/Roles Endpoints

```javascript
// Get all titles
fetch('/wp-admin/admin-ajax.php?action=digical_get_titles', { method: 'POST' });

// Add title
fetch('/wp-admin/admin-ajax.php?action=digical_add_title', {
  method: 'POST',
  body: new URLSearchParams({ title: 'Dr.' })
});

// Edit title
fetch('/wp-admin/admin-ajax.php?action=digical_edit_title', {
  method: 'POST',
  body: new URLSearchParams({
    id: 'title_uuid',
    title: 'Dr. (Ph.D.)'
  })
});

// Delete title
fetch('/wp-admin/admin-ajax.php?action=digical_delete_title', {
  method: 'POST',
  body: new URLSearchParams({ id: 'title_uuid' })
});
```

Same pattern for roles - replace `digical_*_title` with `digical_*_role` and use `role` parameter.

## 🔄 Automatic Updates from GitHub

DigiCal checks GitHub for updates automatically every 1 hour.

### To Update:
1. Go to **Plugins** in WordPress admin
2. If update available, click "Update now"
3. Plugin updates automatically from GitHub release

### Manual Check:
Go to **Dashboard > Updates** and click "Check Again"

### How It Works:
- Reads latest release from GitHub API
- Compares version numbers
- Downloads ZIP from GitHub release assets
- WordPress handles installation/update

## 📦 File Structure

```
digi-cal/
├── digi-cal.php                      # Main plugin file
├── README.md                         # This file
├── LICENSE                           # GPL v2 license
├── .github/
│   └── workflows/
│       └── release.yml              # GitHub Actions for releases
├── admin/
│   ├── days-ajax-db.php             # Days database layer
│   ├── days.php                      # Days admin UI
│   ├── venues-ajax-db.php           # Venues database layer
│   ├── venues.php                    # Venues admin UI
│   ├── titles-roles-ajax-db.php    # Titles/Roles database layer
│   ├── configuration.php             # Titles/Roles admin UI
│   ├── section-wrapper.php           # Admin page wrapper/sidebar
│   └── ...
├── includes/
│   ├── github-updater.php            # GitHub automatic updater
│   ├── helpers.php                   # Helper functions
│   └── ...
├── assets/
│   ├── css/
│   │   └── admin.css                 # Admin styling
│   └── js/
│       └── admin.js                  # Admin JavaScript
└── data/
    └── days.csv                      # Legacy CSV (will be deprecated)
```

## 🐛 Troubleshooting

### Plugin won't activate
**Solution:** Check PHP version (must be 7.0+) and WordPress version (5.0+)
```php
// Check requirements
echo "PHP: " . PHP_VERSION;
echo "WordPress: " . get_bloginfo('version');
```

### Tables not created
**Solution:** Re-activate the plugin or check database permissions
```sql
-- Check if tables exist
SHOW TABLES LIKE 'wp_digical_%';
```

### Updates not showing
**Solution:** GitHub API might be rate-limited or inaccessible
```php
// Check transient cache
delete_transient('digical_github_release_info');
```

### AJAX requests failing
**Check:**
1. Browser console for errors (F12)
2. User has `manage_options` capability
3. WordPress debug log: `/wp-content/debug.log`

## 🔐 Security

All security best practices implemented:

✅ Admin-only access  
✅ Prepared statements (no SQL injection)  
✅ Input sanitization  
✅ HTML escaping (no XSS)  
✅ Capability checks  
✅ No known vulnerabilities  

For security issues, please report privately to [maintainers].

## 📋 Development Roadmap

### v1.2 ✅ Current (Nov 2025)
- Speakers titles & roles configuration
- GitHub automatic updates

### v1.1 ✅
- Database-backed storage
- Days & Venues CRUD
- Professional admin UI

### v1.3 (Planned)
- Phase 2B: Speakers management
- Speakers profiles with titles/roles
- Bulk import/export

### v2.0 (Planned)
- Phase 3: Sessions/Events management
- Phase 4: REST API layer
- Phase 5: Frontend calendar display
- Email notifications
- Event registration system

## 🤝 Contributing

We welcome contributions! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the GNU General Public License v2.0 or later - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with WordPress best practices
- Inspired by professional conference management systems
- Thanks to the WordPress community

## 📞 Support

- 🐛 [Report Bugs](../../issues)
- 💡 [Request Features](../../discussions)
- 📖 [Read Documentation](../../wiki)
- 💬 [Start Discussions](../../discussions)

---

**Made with ❤️ for WordPress**

GitHub: [Your GitHub Username]/digi-cal  
WordPress.org: (Coming soon)  
License: GPL v2.0+
