# DigiCal - WordPress Conference Calendar Plugin

![Version](https://img.shields.io/badge/version-1.2-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![WordPress](https://img.shields.io/badge/wordpress-5.0%2B-blue)
![PHP](https://img.shields.io/badge/php-7.0%2B-blue)

A professional WordPress plugin for managing conference and event calendars with comprehensive backend management tools. Store and organize days, venues, speakers, and sessions in a beautifully integrated admin interface.

## Features

### Core Features ✨
- **Days Management** - Create and organize event days with time slots
- **Venues Management** - Manage primary and secondary venues with hierarchical relationships
- **Speakers Configuration** - Define and manage speaker titles and roles
- **Database-Backed** - All data stored securely in WordPress database (no CSV files)
- **Professional UI** - Clean, modern admin interface matching WordPress standards
- **Responsive Design** - Works perfectly on desktop, tablet, and mobile devices

### Technical Features 🔧
- **Inline Editing** - Edit items without page reloads
- **Real-time Updates** - Changes reflect immediately in the UI
- **Security First** - Prepared statements, input sanitization, XSS prevention
- **Admin-Only Access** - Managed capabilities system
- **Automatic Updates** - Pull updates directly from GitHub releases
- **Clean Code** - Well-organized, documented, follows WordPress standards

### Database Tables 🗄️
- `wp_digical_days` - Event days with time ranges
- `wp_digical_venues` - Primary and secondary venues
- `wp_digical_titles` - Speaker titles (Dr., Prof., etc.)
- `wp_digical_roles` - Speaker roles (Speaker, Moderator, etc.)
- `wp_digical_speakers_roles` - Many-to-many speaker-role relationships

## Installation

### From WordPress Admin
1. Download the latest `.zip` file from [Releases](https://github.com/YOUR_USERNAME/digi-cal/releases)
2. Go to **Plugins > Add New > Upload Plugin**
3. Select the ZIP file and click **Install Now**
4. Click **Activate Plugin**

### From GitHub (for development)
```bash
git clone https://github.com/YOUR_USERNAME/digi-cal.git /path/to/wp-content/plugins/digi-cal
cd digi-cal
```

## Quick Start

After activation:

1. **Go to** `WordPress Admin > DigiCal`
2. **Manage Days** - Add event dates and time slots
3. **Manage Venues** - Create primary venues and sub-locations
4. **Configuration** - Set up speaker titles and roles

## Requirements

- WordPress 5.0 or higher
- PHP 7.0 or higher
- MySQL 5.6 or higher (or equivalent)
- Administrator access
- JavaScript enabled

## Usage

### Managing Days
1. Navigate to **DigiCal > Days**
2. Enter date (DD/MM/YYYY format), start time, and end time
3. Click **Save Day**
4. Edit or delete using the action buttons

### Managing Venues
1. Navigate to **DigiCal > Venues**
2. Select venue type (Primary or Sub-venue)
3. Enter venue name and address
4. For sub-venues, select the primary venue
5. Click **Save Venue**

### Configuring Titles & Roles
1. Navigate to **DigiCal > Speakers > Configuration**
2. Add titles (left column) and roles (right column)
3. Edit or delete using the action buttons

## Development

### Project Structure
```
digi-cal/
├── admin/                          # Admin UI files
│   ├── days-ajax-db.php           # Days database & AJAX layer
│   ├── days.php                   # Days admin interface
│   ├── venues-ajax-db.php         # Venues database & AJAX layer
│   ├── venues.php                 # Venues admin interface
│   ├── titles-roles-ajax-db.php   # Titles/Roles database & AJAX layer
│   ├── configuration.php          # Titles/Roles admin interface
│   └── section-wrapper.php        # Layout wrapper
├── includes/                       # Core plugin files
│   ├── github-updater.php         # GitHub auto-update system
│   ├── helpers.php                # Helper functions
│   └── meta-boxes.php             # Meta boxes
├── assets/
│   ├── css/                       # Stylesheets
│   └── js/                        # JavaScript
├── digi-cal.php                   # Main plugin file
├── LICENSE                        # MIT License
└── README.md                      # This file
```

### Code Style
- Follows WordPress Coding Standards
- Uses prepared statements for database queries
- Proper input sanitization and output escaping
- Well-commented code

### Database Layer Pattern
Each module has:
1. Database functions (`*_all_rows()`, `*_insert_row()`, `*_update_row()`, `*_delete_row()`)
2. AJAX handlers (`wp_ajax_*` actions)
3. Validation & security checks

### Adding New Features
1. Create database layer in `admin/module-ajax-db.php`
2. Create admin UI in `admin/module.php`
3. Register in `digi-cal.php`:
   - Add `require_once` for the module
   - Add activation hook for table creation
   - Add menu items

## Contributing

Contributions are welcome! Here's how:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Versioning

This plugin follows [Semantic Versioning](https://semver.org/):
- **MAJOR** - Breaking changes
- **MINOR** - New features (backward compatible)
- **PATCH** - Bug fixes (backward compatible)

Release format: `v1.2.3`

## Automatic Updates

The plugin checks GitHub automatically for updates and notifies administrators when a new version is available. Updates can be installed directly from the WordPress Plugins page.

### Configuration
To use automatic updates with your GitHub account:
1. Navigate to **Settings > DigiCal** (if you add this menu item)
2. Enter your GitHub username
3. The plugin will pull releases from your repository

## Roadmap

### Phase 1: Stabilization (Complete ✅)
- [x] Core infrastructure
- [x] Days management
- [x] Venues management
- [x] Tests & documentation

### Phase 2: Speakers Configuration (Complete ✅)
- [x] Titles management
- [x] Roles management
- [x] Speaker-role relationships

### Phase 3: Speakers Management (Planned 🔄)
- [ ] Speaker profiles
- [ ] Speaker CRUD operations
- [ ] Speaker assignment to events

### Phase 4: Sessions/Events (Planned 🔄)
- [ ] Session management
- [ ] Session-speaker relationships
- [ ] Conflict detection

### Phase 5: REST API (Planned 🔄)
- [ ] RESTful endpoints
- [ ] Third-party integrations
- [ ] iCalendar export

### Phase 6: Frontend Calendar (Planned 🔄)
- [ ] Public calendar shortcode
- [ ] Event display
- [ ] Event registration

## Frequently Asked Questions

### Q: Is this plugin free?
**A:** Yes! DigiCal is open-source and licensed under MIT.

### Q: Can I customize it?
**A:** Absolutely! The code is well-documented and follows WordPress standards.

### Q: Will it work on my hosting?
**A:** Yes, if you have WordPress 5.0+ and PHP 7.0+. Works on any hosting that runs WordPress.

### Q: How do I get automatic updates?
**A:** The plugin automatically checks GitHub for updates. When available, you'll see an update notice in the Plugins page.

### Q: Can I contribute?
**A:** Yes! We welcome pull requests. See the Contributing section above.

### Q: How is data stored?
**A:** All data is stored in WordPress database tables with proper security, not in CSV or config files.

## Security

- ✅ All database queries use prepared statements
- ✅ Input sanitization on all POST data
- ✅ Output escaping to prevent XSS
- ✅ Capability checks for admin-only features
- ✅ CSRF protection via nonce validation
- ✅ No hardcoded credentials or sensitive data

## Performance

- Optimized database queries with indexes
- Efficient caching of GitHub release data
- Minimal admin overhead
- Responsive UI with AJAX operations

## Support

- 📖 [Documentation](./docs/)
- 🐛 [Report Issues](https://github.com/YOUR_USERNAME/digi-cal/issues)
- 💬 [Discussions](https://github.com/YOUR_USERNAME/digi-cal/discussions)
- 📧 Contact: [your-email@example.com]

## License

DigiCal is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Authors

- **DigiCal Contributors** - Initial development and ongoing maintenance

## Acknowledgments

- Built with WordPress standards and best practices
- Inspired by the WordPress community
- Special thanks to all contributors

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for detailed version history.

---

**Made with ❤️ for the WordPress community**

Star us on GitHub if you find DigiCal useful! ⭐
