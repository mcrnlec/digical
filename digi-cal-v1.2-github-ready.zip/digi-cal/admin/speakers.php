<?php
if (!defined('ABSPATH')) exit;

echo '<h1>Manage Speakers &amp; Moderators</h1><p>Speaker management content here.</p>';
