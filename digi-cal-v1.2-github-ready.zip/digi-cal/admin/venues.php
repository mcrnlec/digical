<?php
if (!defined('ABSPATH')) exit;

/**
 * Venues admin UI (inline edit like Days).
 * Depends on AJAX handlers from admin/venues-ajax-db.php.
 */
?>
<style>
/* --- keep your palette and table look --- */
.digical-controls { display:flex; gap:12px; align-items:center; margin:16px 0; }
.digical-controls .wide { min-width: 240px; }
.digical-btn { background:#2271b1; color:#fff; border:0; border-radius:4px; padding:6px 12px; cursor:pointer; }
.digical-btn:disabled { opacity:.5; cursor:default; }
.digical-btn-red { background:#dc3232; color:#fff; }
.digical-btn-green { background:#1a8f5d; color:#fff; }

.table-wrap { margin-top:10px; }
.digical-table { width:100%; border-collapse:collapse; background:#fff; }
.digical-table th { background:#0b6ea6; color:#fff; text-align:left; padding:10px; font-weight:600; }
.digical-table td { padding:12px 10px; border-bottom:1px solid #c7d5e0; }
.digical-actions .digical-btn { margin-right:8px; }

.primary-bold { font-weight:700; } /* bold primary rows */
.inline-input, .inline-select { width:100%; box-sizing:border-box; }

.bulkbar { display:none; margin:10px 0; }
.bulkbar.show { display:block; }
.bulkbar .digical-btn-red { background:#d63638; }
</style>

<div class="digical-controls">
  <select id="venue_type" class="wide">
    <option value="primary">Primary</option>
    <option value="secondary">Sub-venue</option>
  </select>

  <select id="parent_select" class="wide" style="display:none"></select>

  <input type="text" id="venue_name" class="wide" placeholder="Venue / sub-venue name">

  <input type="text" id="venue_address" class="wide" placeholder="Venue address">

  <button id="add_venue" class="digical-btn">Save Venue</button>
</div>

<div class="bulkbar" id="bulkbar">
  <button id="bulk_delete" class="digical-btn digical-btn-red">Delete selected</button>
</div>

<div class="table-wrap">
  <table class="digical-table" id="venues_table" aria-live="polite">
    <thead>
      <tr>
        <th style="width:42px;"><input type="checkbox" id="chk_all"></th>
        <th style="width:120px;">Type</th>
        <th style="width:240px;">Primary venue</th>
        <th style="width:220px;">Sub-venue</th>
        <th>Venue address</th>
        <th style="width:160px;">Actions</th>
      </tr>
    </thead>
    <tbody></tbody>
  </table>
</div>

<script>
(function($){
  // Use either localized DIGICAL.ajaxurl or core admin ajaxurl
  const AURL = (window.DIGICAL && DIGICAL.ajaxurl) || window.ajaxurl;

  let VENUES = [];           // latest dataset from server
  let PRIMARIES = [];        // cached primary rows for selects

  function loadVenues() {
    $.post(AURL, { action:'digical_db_get_venues' }, function(resp){
      if (!resp || !resp.success) { alert(resp?.data?.message || 'Load failed'); return; }
      VENUES = resp.data.venues || [];
      PRIMARIES = VENUES.filter(v => v.type === 'primary');
      renderParentSelectInForm();
      renderTable();
    });
  }

  function renderParentSelectInForm() {
    const $sel = $('#parent_select');
    const hasPrimaries = PRIMARIES.length > 0;
    $sel.empty();
    if (hasPrimaries) {
      $sel.append('<option value="">— Select primary —</option>');
      PRIMARIES.forEach(p => {
        $sel.append(`<option value="${p.id}">${escapeHtml(p.name)}</option>`);
      });
    }
    const type = $('#venue_type').val();
    $sel.toggle(type === 'secondary' && hasPrimaries);
  }

  // Top form behavior
  $('#venue_type').on('change', function(){
    renderParentSelectInForm();
  });

  // Auto-fill address when a parent is picked in the top form (for convenience).
  $('#parent_select').on('change', function(){
    const pid = $(this).val();
    const parent = PRIMARIES.find(p => p.id === pid);
    if (parent) {
      $('#venue_address').val(parent.address || '');
    }
  });

  $('#add_venue').on('click', function(e){
    e.preventDefault();
    const type = $('#venue_type').val();
    const name = $('#venue_name').val().trim();
    const address = $('#venue_address').val().trim();
    const pid = $('#parent_select').is(':visible') ? $('#parent_select').val() : '';

    $.post(AURL, {
      action: 'digical_db_add_venue',
      venue_type: type,
      venue_name: name,
      venue_address: address,
      parent_id: pid
    }, function(resp){
      if (!resp || !resp.success) {
        alert(resp?.data?.message || 'Save failed');
        return;
      }
      // reset fields, reload table
      $('#venue_name').val('');
      $('#venue_address').val('');
      $('#parent_select').val('');
      loadVenues();
    });
  });

  // -------- Table rendering --------
  function renderTable() {
    const $tb = $('#venues_table tbody');
    $tb.empty();

    VENUES.forEach(row => {
      const tr = document.createElement('tr');
      tr.dataset.id = row.id;

      const checkedCell = `<td><input type="checkbox" class="chk_row"></td>`;
      const typeCell = `<td>${row.type === 'primary' ? 'Primary' : 'Sub-venue'}</td>`;

      const primaryName = row.type === 'primary' ? row.name : (row.parent_name || '');
      const primaryHtml = row.type === 'primary'
          ? `<td class="${row.type === 'primary' ? 'primary-bold' : ''}">${escapeHtml(row.name)}</td>`
          : `<td>${escapeHtml(primaryName)}</td>`;

      const subName = row.type === 'primary' ? '' : row.name;
      const subCell = `<td>${escapeHtml(subName)}</td>`;

      const addrCell = `<td>${escapeHtml(row.address || '')}</td>`;

      const actions = `
        <td class="digical-actions">
          <button class="digical-btn btn-edit">Edit</button>
          <button class="digical-btn digical-btn-red btn-del">Delete</button>
        </td>`;

      tr.innerHTML = checkedCell + typeCell + primaryHtml + subCell + addrCell + actions;
      $tb.append(tr);
    });

    // bind row events
    bindRowHandlers();
    updateBulkBar();
  }

  function bindRowHandlers() {
    // checkbox selection
    $('#chk_all').off('change').on('change', function(){
      const on = $(this).is(':checked');
      $('#venues_table .chk_row').prop('checked', on);
      updateBulkBar();
    });

    $('#venues_table .chk_row').off('change').on('change', function(){
      if (!$(this).is(':checked')) $('#chk_all').prop('checked', false);
      updateBulkBar();
    });

    // Delete single
    $('#venues_table .btn-del').off('click').on('click', function(){
      const id = $(this).closest('tr').data('id');
      $.post(AURL, { action:'digical_db_delete_venue', id }, function(resp){
        if (!resp || !resp.success) { alert(resp?.data?.message || 'Delete failed'); return; }
        VENUES = resp.data.venues || [];
        PRIMARIES = VENUES.filter(v => v.type === 'primary');
        renderParentSelectInForm();
        renderTable();
      });
    });

    // Inline edit
    $('#venues_table .btn-edit').off('click').on('click', function(){
      const $tr = $(this).closest('tr');
      if ($tr.data('edit') === '1') return;
      $tr.data('edit', '1');

      const id     = $tr.data('id');
      const v      = VENUES.find(x => x.id === id);
      const isPrim = v.type === 'primary';

      // Build inline editor cells
      // col 0 = checkbox (leave)
      // col 1 = type select
      const $cells = $tr.children('td');

      // Type
      $cells.eq(1).html(`
        <select class="inline-select edit-type">
          <option value="primary"${isPrim?' selected':''}>Primary</option>
          <option value="secondary"${!isPrim?' selected':''}>Sub-venue</option>
        </select>
      `);

      // Primary venue cell: for primary -> editable name; for sub -> parent select
      if (isPrim) {
        $cells.eq(2).html(`<input type="text" class="inline-input edit-primary-name" value="${escAttr(v.name)}">`);
        $cells.eq(3).html(`<input type="text" class="inline-input edit-sub-name" value="" disabled>`); // no sub-name for primary
      } else {
        // parent select + sub-venue name
        let html = `<select class="inline-select edit-parent">`;
        PRIMARIES.forEach(p => {
          const sel = (p.id === v.parent_id) ? ' selected' : '';
          html += `<option value="${p.id}"${sel}>${escAttr(p.name)}</option>`;
        });
        html += `</select>`;
        $cells.eq(2).html(html);
        $cells.eq(3).html(`<input type="text" class="inline-input edit-sub-name" value="${escAttr(v.name)}">`);
      }

      // Address (always free editable; server will override children when a primary changes)
      $cells.eq(4).html(`<input type="text" class="inline-input edit-address" value="${escAttr(v.address || '')}">`);

      // Actions -> Save / Cancel
      $cells.eq(5).html(`
        <button class="digical-btn digical-btn-green btn-save">Save</button>
        <button class="digical-btn btn-cancel">Cancel</button>
      `);

      // React when switching type in-editor
      $cells.eq(1).find('.edit-type').on('change', function(){
        const newType = $(this).val();
        if (newType === 'primary') {
          // primary: primary name editable, sub-name disabled, no parent select
          $cells.eq(2).html(`<input type="text" class="inline-input edit-primary-name" value="${escAttr(isPrim ? v.name : (v.parent_name || ''))}">`);
          $cells.eq(3).html(`<input type="text" class="inline-input edit-sub-name" value="" disabled>`);
        } else {
          // sub: parent dropdown + sub-name
          let html = `<select class="inline-select edit-parent">`;
          PRIMARIES.forEach(p => { html += `<option value="${p.id}">${escAttr(p.name)}</option>`; });
          html += `</select>`;
          $cells.eq(2).html(html);
          const suggested = isPrim ? '' : v.name;
          $cells.eq(3).html(`<input type="text" class="inline-input edit-sub-name" value="${escAttr(suggested)}">`);
        }
      });

      // Save/cancel handlers
      $cells.eq(5).find('.btn-cancel').on('click', function(){ renderTable(); });

      $cells.eq(5).find('.btn-save').on('click', function(){
        const newType   = $cells.eq(1).find('.edit-type').val();
        let   name, parentId = '';

        if (newType === 'primary') {
          name = $cells.eq(2).find('.edit-primary-name').val().trim();
        } else {
          parentId = $cells.eq(2).find('.edit-parent').val();
          name     = $cells.eq(3).find('.edit-sub-name').val().trim();
        }
        const address = $cells.eq(4).find('.edit-address').val().trim();

        $.post(AURL, {
          action: 'digical_db_edit_venue',
          id: id,
          venue_type: newType,
          venue_name: name,
          venue_address: address,
          parent_id: parentId
        }, function(resp){
          if (!resp || !resp.success) { alert(resp?.data?.message || 'Update failed'); return; }
          VENUES = resp.data.venues || [];
          PRIMARIES = VENUES.filter(v => v.type === 'primary');
          renderParentSelectInForm();
          renderTable(); // fresh state; if primary changed address, children already updated server-side
        });
      });
    });
  }

  function updateBulkBar() {
    const selCount = $('#venues_table .chk_row:checked').length;
    $('#bulkbar').toggleClass('show', selCount >= 2);
  }

  $('#bulk_delete').on('click', function(){
    const ids = $('#venues_table .chk_row:checked').closest('tr').map(function(){ return $(this).data('id'); }).get();
    if (ids.length < 2) return;
    $.post(AURL, { action:'digical_db_delete_venues', ids: ids }, function(resp){
      if (!resp || !resp.success) { alert(resp?.data?.message || 'Bulk delete failed'); return; }
      VENUES = resp.data.venues || [];
      PRIMARIES = VENUES.filter(v => v.type === 'primary');
      renderParentSelectInForm();
      renderTable();
    });
  });

  function escapeHtml(s){ return (s||'').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }
  function escAttr(s){ return escapeHtml(s); }

  // Init
  $(document).ready(loadVenues);
})(jQuery);
</script>
