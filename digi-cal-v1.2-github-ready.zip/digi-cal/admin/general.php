<?php
if (!defined('ABSPATH')) exit;
include DIGICAL_PATH . 'admin/section-wrapper.php';
digical_section_wrapper('General', '<p>Welcome to digi-cal. Select a menu to begin!</p>');
