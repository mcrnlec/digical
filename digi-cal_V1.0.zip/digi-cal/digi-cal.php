<?php
/*
Plugin Name: DigiCal
Description: Conference calendar with backend management (DB-backed).
Version: 1.0
Author: DIGIT
*/

if (!defined('ABSPATH')) exit;

define('DIGICAL_PATH', plugin_dir_path(__FILE__));
define('DIGICAL_URL',  plugin_dir_url(__FILE__));

/*
 * Load DB + AJAX layer so admin-ajax.php always has handlers.
 * File must exist: admin/days-ajax-db.php
 * It defines:
 *   DIGICAL_DAYS_TABLE
 *   digical_days_ensure_table()
 *   digical_days_all_rows(), digical_days_insert_row(), ...
 *   wp_ajax_ handlers: digical_db_probe, digical_db_get_days, add, edit, delete
 */
require_once DIGICAL_PATH . 'admin/days-ajax-db.php';

/* ---------------- Activation: ensure table ---------------- */
register_activation_hook(__FILE__, function () {
    if (function_exists('digical_days_ensure_table')) {
        digical_days_ensure_table();
    }
});

/* ---------------- Helper: safe wrapper include ---------------- */
function digical_safe_include_section_wrapper() {
    if (!function_exists('digical_section_wrapper')) {
        $file = DIGICAL_PATH . 'admin/section-wrapper.php';
        if (file_exists($file)) include_once $file;
    }
    if (!function_exists('digical_section_wrapper')) {
        function digical_section_wrapper($active, $content_html) {
            echo '<div class="wrap"><h1>DigiCal</h1>' . $content_html . '</div>';
        }
    }
}

/* ---------------- Admin Menu ---------------- */
add_action('admin_menu', function () {

    // Top-level: General
    add_menu_page(
        'DigiCal', 'DigiCal', 'manage_options', 'digical',
        function () {
            digical_safe_include_section_wrapper();
            $content = '<h2>General</h2><p>Use the sidebar to manage Days, Venues, and Speakers.</p>';
            digical_section_wrapper('General', $content);
        },
        'dashicons-calendar-alt', 25
    );

    // Days main page (UI)
    add_submenu_page(
        'digical', 'Days', 'Days', 'manage_options', 'digical-days',
        function () {
            digical_safe_include_section_wrapper();
            ob_start();
            include DIGICAL_PATH . 'admin/days.php';   // UI; its JS calls digical_db_* AJAX
            $content = ob_get_clean();
            digical_section_wrapper('Days', $content);
        }
    );

    // Optional placeholders
    add_submenu_page(
        'digical', 'Venues', 'Venues', 'manage_options', 'digical-venues',
        function () {
            digical_safe_include_section_wrapper();
            $content = '<h2>Venues</h2><p>(Coming soon)</p>';
            digical_section_wrapper('Venues', $content);
        }
    );
    add_submenu_page(
        'digical', 'Speakers', 'Speakers', 'manage_options', 'digical-speakers',
        function () {
            digical_safe_include_section_wrapper();
            $content = '<h2>Speakers</h2><p>(Coming soon)</p>';
            digical_section_wrapper('Speakers', $content);
        }
    );

    // ---- Dynamic per-day subpages, so sidebar day links work ----
    if (function_exists('digical_days_all_rows')) {
        $days = digical_days_all_rows();
        foreach ($days as $d) {
            $slug = 'digical-day-' . sanitize_key($d['id']);
            add_submenu_page(
                'digical',
                'Day ' . esc_html($d['date']),
                '', // hidden from WP submenu; we link to it from the custom sidebar
                'manage_options',
                $slug,
                function () use ($d) {
                    digical_safe_include_section_wrapper();
                    $dateLabel = preg_match('/^(\d{2})(\d{2})(\d{4})$/', $d['date'], $m)
                                ? "{$m[1]}.{$m[2]}.{$m[3]}"
                                : esc_html($d['date']);
                    $content  = '<h2>Day ' . $dateLabel . '</h2>';
                    $content .= '<p><strong>Start:</strong> ' . esc_html($d['start_time']) .
                                ' &nbsp; <strong>End:</strong> ' . esc_html($d['end_time']) . '</p>';
                    $content .= '<p><a class="button button-primary" href="' .
                                esc_url( admin_url('admin.php?page=digical-days') ) .
                                '">Back to Days</a></p>';
                    digical_section_wrapper('Days', $content);
                }
            );
        }
    }
});

/* ---------------- Admin assets (optional) ---------------- */
add_action('admin_enqueue_scripts', function () {
    $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
    if ($page && ($page === 'digical' || str_starts_with($page, 'digical-'))) {
        $css = DIGICAL_PATH . 'assets/css/admin.css';
        if (file_exists($css)) {
            wp_enqueue_style('digical-admin-css', DIGICAL_URL . 'assets/css/admin.css', [], '1.3');
        }
    }
});
