<?php
if (!defined('ABSPATH')) exit;

$venues = function_exists('digical_get_csv_rows')
    ? digical_get_csv_rows(DIGICAL_VENUES_CSV)
    : [];

ob_start();
?>
<!-- Your styles here -->
<script> var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>'; </script>
<h1>Manage Venues</h1>
<form id="venue-form" style="max-width:700px; margin-bottom:30px;" autocomplete="off">
    <!-- Venue form fields... -->
    <select id="venue_type" name="venue_type" required>
        <option value="" disabled selected>Select type</option>
        <option value="primary">Primary (Parent)</option>
        <option value="secondary">Secondary (Child)</option>
    </select>
    <input type="text" id="venue_name" name="venue_name" required placeholder="Venue Name" />
    <input type="text" id="venue_address" name="venue_address" required placeholder="Venue Address" />
    <button type="submit" id="save_venue_btn">Save Venue</button>
</form>
<table class="digical-custom-table">
    <thead>
        <tr>
            <th>Venue Type</th>
            <th>Venue Name</th>
            <th>Venue Address</th>
            <th>Created</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($venues as $venue): ?>
            <tr>
                <td><?php echo $venue['type']; ?></td>
                <td><?php echo $venue['name']; ?></td>
                <td><?php echo $venue['address']; ?></td>
                <td><?php echo date("Y-m-d H:i", intval($venue['created'])); ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<script>
document.getElementById('venue-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var data = {
        action: 'digical_add_venue',
        venue_type: document.getElementById('venue_type').value,
        venue_name: document.getElementById('venue_name').value,
        venue_address: document.getElementById('venue_address').value,
        _wpnonce: "<?php echo wp_create_nonce('digical_nonce'); ?>"
    };
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(data).toString()
    }).then(res => res.json())
      .then(response => {
        if (response.success) {
            window.location.reload();
        } else {
            alert(response.data.message || "Unknown error");
        }
    });
});
</script>
<?php
$content = ob_get_clean();
echo $content;
