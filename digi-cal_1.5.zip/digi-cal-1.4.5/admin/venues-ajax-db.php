<?php
/**
 * DigiCal Venues AJAX & Database
 * FILE: digi-cal/admin/venues-ajax-db.php
 * 
 * All AJAX handlers for venue management:
 * - Get venues for event
 * - Add new venue
 * - Edit existing venue  
 * - Delete single venue
 * - Bulk delete venues
 * - Table creation
 */

if (!defined('ABSPATH')) exit;

/**
 * AJAX: Get all venues for event
 */
add_action('wp_ajax_digical_db_get_venues', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    
    if (!$event_id) {
        wp_send_json_error(['message' => 'Event ID is required']);
        return;
    }
    
    $table = $wpdb->prefix . 'digical_venues';
    $venues = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY type DESC, name ASC", $event_id),
        ARRAY_A
    );
    
    wp_send_json_success(['venues' => is_array($venues) ? $venues : []]);
});

/**
 * AJAX: Add new venue (form submission)
 */
add_action('wp_ajax_digical_db_add_venue', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    
    global $wpdb;
    
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    if (!$event_id) {
        wp_send_json_error(['message' => 'Event ID is required']);
        return;
    }
    
    $id = 'venue_' . substr(md5(uniqid()), 0, 20);
    $venue_type = isset($_POST['venue_type']) ? sanitize_text_field($_POST['venue_type']) : 'primary';
    $type = ($venue_type === 'secondary') ? 'sub-venue' : 'primary';
    $name = isset($_POST['venue_name']) ? sanitize_text_field($_POST['venue_name']) : '';
    $address = isset($_POST['venue_address']) ? sanitize_textarea_field($_POST['venue_address']) : '';
    
    if (!$name) {
        wp_send_json_error(['message' => 'Venue name is required']);
        return;
    }
    
    $parent_id = null;
    if ($type === 'sub-venue') {
        $parent_id = isset($_POST['parent_id']) ? sanitize_text_field($_POST['parent_id']) : null;
        if (!$parent_id) {
            wp_send_json_error(['message' => 'Parent venue is required for sub-venues']);
            return;
        }
    }
    
    $table = $wpdb->prefix . 'digical_venues';
    $result = $wpdb->insert(
        $table,
        ['id' => $id, 'event_id' => $event_id, 'type' => $type, 'name' => $name, 'address' => $address, 'parent_id' => $parent_id],
        ['%s', '%s', '%s', '%s', '%s', '%s']
    );
    
    if ($result === false) {
        wp_send_json_error(['message' => 'Database error']);
        return;
    }
    
    wp_send_json_success(['id' => $id, 'message' => 'Venue created']);
});

/**
 * AJAX: Edit existing venue
 */
add_action('wp_ajax_digical_db_edit_venue', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'digical_venues';
    
    $id = isset($_POST['id']) && !empty($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
    if (!$id) {
        wp_send_json_error(['message' => 'Venue ID is required']);
        return;
    }
    
    $event_id = isset($_POST['event_id']) && !empty($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    
    if (!$event_id) {
        $existing = $wpdb->get_row($wpdb->prepare("SELECT event_id FROM $table WHERE id = %s", $id), ARRAY_A);
        if (!$existing) {
            wp_send_json_error(['message' => 'Venue not found']);
            return;
        }
        $event_id = $existing['event_id'];
    }
    
    $venue_type = isset($_POST['venue_type']) ? sanitize_text_field($_POST['venue_type']) : 'primary';
    $type = ($venue_type === 'secondary') ? 'sub-venue' : 'primary';
    $name = isset($_POST['venue_name']) ? sanitize_text_field($_POST['venue_name']) : '';
    $address = isset($_POST['venue_address']) ? sanitize_textarea_field($_POST['venue_address']) : '';
    
    if (!$name) {
        wp_send_json_error(['message' => 'Venue name is required']);
        return;
    }
    
    $parent_id = null;
    if ($type === 'sub-venue') {
        $parent_id = isset($_POST['parent_id']) ? sanitize_text_field($_POST['parent_id']) : null;
        if (!$parent_id) {
            wp_send_json_error(['message' => 'Parent venue is required']);
            return;
        }
    }
    
    $result = $wpdb->update(
        $table,
        ['type' => $type, 'name' => $name, 'address' => $address, 'parent_id' => $parent_id],
        ['id' => $id, 'event_id' => $event_id],
        ['%s', '%s', '%s', '%s'],
        ['%s', '%s']
    );
    
    if ($type === 'primary') {
        $wpdb->update($table, ['address' => $address], ['parent_id' => $id, 'event_id' => $event_id], ['%s'], ['%s', '%s']);
    }
    
    if ($result === false) {
        wp_send_json_error(['message' => 'Database error']);
        return;
    }
    
    wp_send_json_success(['id' => $id, 'message' => 'Venue updated']);
});

/**
 * AJAX: Delete single venue
 */
add_action('wp_ajax_digical_db_delete_venue', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'digical_venues';
    
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    $venue_id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
    
    if (!$venue_id || !$event_id) {
        wp_send_json_error(['message' => 'Venue ID and Event ID required']);
        return;
    }
    
    $wpdb->delete($table, ['id' => $venue_id, 'event_id' => $event_id], ['%s', '%s']);
    wp_send_json_success(['message' => 'Venue deleted']);
});

/**
 * AJAX: Bulk delete venues
 */
add_action('wp_ajax_digical_db_delete_venues', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'digical_venues';
    
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];
    $ids = array_map('sanitize_text_field', $ids);
    
    if (!$event_id || empty($ids)) {
        wp_send_json_error(['message' => 'Event ID and venue IDs required']);
        return;
    }
    
    $deleted = 0;
    foreach ($ids as $id) {
        if ($wpdb->delete($table, ['id' => $id, 'event_id' => $event_id], ['%s', '%s'])) {
            $deleted++;
        }
    }
    
    if ($deleted === 0) {
        wp_send_json_error(['message' => 'No venues deleted']);
        return;
    }
    
    wp_send_json_success(['count' => $deleted, 'message' => $deleted . ' venue(s) deleted']);
});

/**
 * Ensure venues table exists
 */
function digical_venues_ensure_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'digical_venues';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS `$table` (
        `id` varchar(100) NOT NULL PRIMARY KEY,
        `event_id` varchar(100) NOT NULL,
        `type` varchar(20) NOT NULL,
        `name` varchar(255) NOT NULL,
        `address` text DEFAULT NULL,
        `parent_id` varchar(100) DEFAULT NULL,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        KEY `idx_event_id` (`event_id`),
        KEY `idx_type_name` (`type`, `name`),
        KEY `idx_parent` (`parent_id`),
        FOREIGN KEY (`event_id`) REFERENCES {$wpdb->prefix}digical_events(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * Get all venues for active event (helper)
 */
function digical_venues_all_rows() {
    global $wpdb;
    
    $event_id = digical_get_active_event_id();
    if (!$event_id) {
        return [];
    }
    
    $table = $wpdb->prefix . 'digical_venues';
    $venues = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY type DESC, name ASC", $event_id),
        ARRAY_A
    );
    
    return is_array($venues) ? $venues : [];
}