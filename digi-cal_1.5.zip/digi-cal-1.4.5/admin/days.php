<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// Permission check
if (!current_user_can('manage_options')) {
    wp_die('Sorry, you are not allowed to access this page.');
}

// Get event_id from URL
$event_id = isset($_GET['event_id']) ? sanitize_text_field($_GET['event_id']) : null;

if (!$event_id) {
    echo '<div class="wrap"><h1>DigiCal - Days</h1>';
    echo '<div style="padding: 20px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 5px;">';
    echo '<p>No event selected. Go to <a href="' . esc_url(admin_url('admin.php?page=digical-events')) . '">DigiCal → Events</a> to select an event.</p>';
    echo '</div></div>';
    return;
}

/**
 * 1) Get rows for this event
 */
$table = $wpdb->prefix . 'digical_days';
$query = $wpdb->prepare("
    SELECT id, date, start_time, end_time
    FROM `$table`
    WHERE event_id = %s
    ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC, start_time ASC
", $event_id);
error_log('Days Query: ' . $query);
error_log('Event ID: ' . $event_id);
$rows = $wpdb->get_results($query, ARRAY_A);
error_log('Rows found: ' . count($rows));
if (!is_array($rows)) $rows = [];

// Sanitize rows for JSON output
foreach ($rows as &$row) {
    foreach ($row as $key => $value) {
        $row[$key] = sanitize_text_field($value);
    }
}

/**
 * 2) Local helpers
 */
function digical_fmt_date_disp_local($d8){
    $d = preg_replace('/\D+/', '', (string)$d8);
    if (preg_match('/^(\d{2})(\d{2})(\d{4})$/', $d, $m)) {
        return "{$m[1]}.{$m[2]}.{$m[3]}";
    }
    return esc_html($d8);
}
function digical_weekday_name_local($d8){
    $d = preg_replace('/\D+/', '', (string)$d8);
    if (!preg_match('/^(\d{2})(\d{2})(\d{4})$/', $d, $m)) return '';
    $ts = strtotime("{$m[3]}-{$m[2]}-{$m[1]} 00:00:00");
    return $ts ? wp_date('l', $ts) : '';
}

$nonce          = wp_create_nonce('digical_nonce');
$ajaxurl        = admin_url('admin-ajax.php');
$day_manage_base= admin_url('admin.php?page=digical-day-');
?>

<style>
/* ===== Days Management - Modern Professional Styling ===== */

.digical-days-container {
    background: transparent;
    padding: 0;
}

#day-form {
    background: linear-gradient(135deg, #f8fafc 0%, #f0f4f8 100%);
    border: 1px solid #e0e6ed;
    border-radius: 12px;
    padding: 24px;
    margin-bottom: 30px;
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    align-items: flex-end;
}

#day-form input[type="text"] {
    padding: 12px 16px;
    font-size: 14px;
    border: 2px solid #d1d8e0;
    border-radius: 8px;
    box-sizing: border-box;
    transition: all 0.3s ease;
    flex: 1;
    min-width: 160px;
    font-weight: 600;
    color: #2c3e50;
    background: white;
}

#day-form input[type="text"]:focus {
    outline: none;
    border-color: #2271b1;
    box-shadow: 0 0 0 3px rgba(34, 113, 177, 0.1);
}

#day-form input[type="text"]::placeholder {
    color: #7f8c8d;
    font-weight: 500;
}

#save_day_btn {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 12px 32px;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    box-shadow: 0 2px 8px rgba(34, 113, 177, 0.2);
}

#save_day_btn:hover {
    box-shadow: 0 4px 16px rgba(34, 113, 177, 0.3);
    transform: translateY(-2px);
}

.digical-bar {
    display: flex;
    align-items: center;
    gap: 16px;
    margin: 20px 0 24px 0;
}

.digical-bar .bulk-btn {
    display: none;
}

.digical-bar .bulk-btn.show {
    display: inline-block;
}

.view-toggle-bar .bulk-btn {
    display: none;
}

.view-toggle-bar .bulk-btn.show {
    display: inline-block;
}

.digical-bulk {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.2);
}

.digical-bulk:hover {
    box-shadow: 0 4px 16px rgba(231, 76, 60, 0.3);
    transform: translateY(-2px);
}

/* Table Styles */
.digical-custom-table {
    border-collapse: collapse;
    margin-top: 0;
    font-size: 15px;
    table-layout: auto;
    width: 100%;
    background: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    border: 1px solid #e0e6ed;
}

.digical-custom-table th {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    color: #fff;
    text-align: left;
    font-weight: 700;
    font-size: 12px;
    border: none;
    padding: 14px 16px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.digical-custom-table th:first-child {
    padding-left: 16px;
}

.digical-custom-table th:last-child {
    text-align: center;
}

.digical-custom-table td {
    background: #fff;
    padding: 14px 16px;
    border: none;
    border-bottom: 1px solid #ecf0f1;
    vertical-align: middle;
    font-size: 14px;
    color: #2c3e50;
    font-weight: 500;
}

.digical-custom-table tbody tr:last-child td {
    border-bottom: none;
}

.digical-custom-table tbody tr:hover td {
    background: #f8fafc;
}

.digical-custom-table input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: #2271b1;
}

/* Action Buttons */
.digical-btn-action {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    color: #fff;
    border: none;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 12px;
    font-weight: 700;
    margin-right: 4px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-block;
    box-shadow: 0 2px 6px rgba(34, 113, 177, 0.15);
    line-height: 1.4;
    white-space: nowrap;
}

.digical-btn-action:last-of-type {
    margin-right: 0;
}

.digical-btn-action:hover {
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.25);
    transform: translateY(-2px);
}

.digical-btn-action.delete {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    box-shadow: 0 2px 6px rgba(231, 76, 60, 0.15);
}

.digical-btn-action.delete:hover {
    box-shadow: 0 4px 12px rgba(231, 76, 60, 0.25);
}

.digical-btn-config {
    background: linear-gradient(135deg, #27ae60 0%, #229954 100%) !important;
    color: #fff !important;
    border: none;
    border-radius: 6px;
    padding: 8px 12px !important;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    display: inline-block !important;
    text-decoration: none;
    transition: all 0.3s ease;
    box-shadow: 0 2px 6px rgba(39, 174, 96, 0.15);
    text-align: center;
    margin-right: 0;
    line-height: 1.4;
    white-space: nowrap;
}

.digical-btn-config:hover {
    box-shadow: 0 4px 12px rgba(39, 174, 96, 0.25);
    transform: translateY(-2px);
    color: #fff !important;
}

/* Edit Inline Inputs */
input.date-edit {
    width: 110px;
    font-size: 14px;
    padding: 8px 12px;
    box-sizing: border-box;
    border: 2px solid #2271b1;
    border-radius: 6px;
    font-weight: 600;
    background: white;
}

input.time-edit {
    width: 65px;
    font-size: 14px;
    padding: 8px 12px;
    box-sizing: border-box;
    border: 2px solid #2271b1;
    border-radius: 6px;
    font-weight: 600;
    background: white;
}

/* Responsive */
@media (max-width: 768px) {
    #day-form {
        flex-direction: column;
        align-items: stretch;
    }
    
    #day-form input[type="text"],
    #save_day_btn {
        width: 100%;
    }
    
    .digical-custom-table {
        font-size: 13px;
    }
    
    .digical-custom-table td,
    .digical-custom-table th {
        padding: 10px 8px;
    }
    
    .digical-btn-action,
    .digical-btn-config {
        padding: 6px 10px;
        font-size: 11px;
    }
}

/* Masonry Grid */
.digical-day-card {
    background: linear-gradient(135deg, #f8fafc 0%, #f0f4f8 100%);
    border: 2px solid #e0e6ed;
    border-radius: 12px;
    padding: 24px;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
}

.digical-day-card:hover {
    box-shadow: 0 8px 24px rgba(34, 113, 177, 0.15);
    transform: translateY(-4px);
    border-color: #2271b1;
}

.digical-day-card input[type="checkbox"].masonry-chk {
    position: absolute;
    top: 12px;
    left: 12px;
    width: 20px;
    height: 20px;
    cursor: pointer;
    accent-color: #2271b1;
    appearance: auto;
    padding: 0;
}

.digical-day-card-day {
    font-size: 32px;
    font-weight: 900;
    color: #2271b1;
    line-height: 1;
    margin-bottom: 8px;
}

.digical-day-card-date {
    font-size: 18px;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 4px;
    padding-top: 12px;
}

.digical-day-card-name {
    font-size: 14px;
    color: #7f8c8d;
    font-weight: 600;
    margin-bottom: 16px;
}

.digical-day-card-times {
    font-size: 15px;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 16px;
    padding: 12px;
    background: white;
    border-radius: 8px;
    text-align: center;
}

.digical-day-card-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

#days-masonry {
    display: none;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

#days-masonry.show {
    display: grid;
}

/* View Toggle */
.view-toggle-bar {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 20px 0 24px 0;
}

.view-toggle {
    display: flex;
    gap: 12px;
    margin-bottom: 0;
}

.view-toggle-btn {
    background: linear-gradient(135deg, #ecf0f1 0%, #d5dbdb 100%);
    color: #2c3e50;
    border: 2px solid #bdc3c7;
    border-radius: 8px;
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
}

.view-toggle-btn:hover {
    border-color: #2271b1;
    color: #2271b1;
}

.view-toggle-btn.active {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    border-color: #2271b1;
    color: white;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.2);
}

/* Modal Styles */
#edit-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
}

#edit-modal.show {
    display: flex;
}

.modal-content {
    background: white;
    border-radius: 12px;
    padding: 32px;
    max-width: 400px;
    width: 90%;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.modal-content h2 {
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 24px;
    color: #2c3e50;
}

.modal-content .form-group {
    margin-bottom: 16px;
}

.modal-content label {
    display: block;
    font-weight: 600;
    margin-bottom: 6px;
    color: #2c3e50;
    font-size: 14px;
}

.modal-content input {
    width: 100%;
    padding: 10px 12px;
    border: 2px solid #e0e6ed;
    border-radius: 6px;
    font-size: 14px;
    box-sizing: border-box;
    transition: all 0.3s ease;
}

.modal-content input:focus {
    outline: none;
    border-color: #2271b1;
    box-shadow: 0 0 0 3px rgba(34, 113, 177, 0.1);
}

.modal-actions {
    display: flex;
    gap: 12px;
    margin-top: 24px;
}

.modal-actions button {
    flex: 1;
    padding: 12px 16px;
    border: none;
    border-radius: 6px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 14px;
}

#edit-save {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    color: white;
    box-shadow: 0 2px 6px rgba(34, 113, 177, 0.2);
}

#edit-save:hover {
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.3);
    transform: translateY(-2px);
}

#edit-cancel {
    background: #ecf0f1;
    color: #2c3e50;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
}

#edit-cancel:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

@media (max-width: 768px) {
    #days-masonry {
        grid-template-columns: 1fr;
    }
    
    .modal-content {
        padding: 24px;
    }
    
    .view-toggle-bar {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }
}
</style>

<div class="digical-days-container">
    <form id="day-form">
        <input type="text" name="day_date" placeholder="Date (DDMMYYYY)" required>
        <input type="text" name="start_time" placeholder="Start (HH:MM or H)" required>
        <input type="text" name="end_time" placeholder="End (HH:MM or H)" required>
        <button type="submit" id="save_day_btn">+ New Day</button>
    </form>

    <div class="view-toggle-bar">
        <div class="view-toggle">
            <button id="view-table-btn" class="view-toggle-btn active">📊 Table</button>
            <button id="view-masonry-btn" class="view-toggle-btn">📋 Masonry</button>
        </div>
        <button class="bulk-btn digical-bulk" id="bulk-delete-btn">🗑️ Delete Selected</button>
    </div>

    <!-- Table View -->
    <table id="days-table" class="digical-custom-table">
        <thead>
            <tr>
                <th><input type="checkbox" id="chk-all"></th>
                <th>Date</th>
                <th>Day</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th style="text-align: center;">Actions</th>
            </tr>
        </thead>
        <tbody id="days-tbody">
        </tbody>
    </table>

    <!-- Masonry View -->
    <div id="days-masonry"></div>
</div>

<!-- Edit Modal -->
<div id="edit-modal">
    <div class="modal-content">
        <h2>Edit Day</h2>
        <div class="form-group">
            <label for="edit-date">Date (DDMMYYYY)</label>
            <input type="text" id="edit-date" placeholder="06112025">
        </div>
        <div class="form-group">
            <label for="edit-start">Start Time</label>
            <input type="text" id="edit-start" placeholder="09:00">
        </div>
        <div class="form-group">
            <label for="edit-end">End Time</label>
            <input type="text" id="edit-end" placeholder="17:00">
        </div>
        <div class="modal-actions">
            <button type="button" id="edit-save">Save</button>
            <button type="button" id="edit-cancel">Cancel</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function(){
  const ajaxurl   = <?php echo json_encode($ajaxurl); ?>;
  const nonce     = <?php echo json_encode($nonce); ?>;
  const eventId   = <?php echo json_encode($event_id); ?>;
  const managePre = <?php echo json_encode($day_manage_base); ?>;

  const tbody   = document.querySelector('#days-tbody');
  const form    = document.getElementById('day-form');
  const bulkBtn = document.getElementById('bulk-delete-btn');
  const chkAll  = document.getElementById('chk-all');

  // Helpers
  const fmtDate = s => String(s).replace(/^(\d{2})(\d{2})(\d{4})$/, '$1.$2.$3');
  const fmtTime = t => {
    const x = String(t).trim();
    if (/^\d{1,2}$/.test(x)) return x.padStart(2,'0') + ':00';
    if (/^\d{1,2}:\d{2}$/.test(x)) { const [h,m]=x.split(':'); return h.padStart(2,'0') + ':' + m; }
    return x;
  };
  function validateDate(ddmmyyyy){
    const clean = String(ddmmyyyy).replace(/\./g,'');
    if (!/^\d{8}$/.test(clean)) return false;
    const d = parseInt(clean.slice(0,2),10);
    const m = parseInt(clean.slice(2,4),10);
    const y = parseInt(clean.slice(4,8),10);
    const dt = new Date(y, m-1, d);
    return dt.getFullYear()===y && (dt.getMonth()+1)===m && dt.getDate()===d;
  }
  function weekdayName(dateStr){
    const p = String(dateStr).split('.');
    const d = new Date(`${p[2]}-${p[1]}-${p[0]}T00:00:00`);
    return isNaN(d) ? '' : d.toLocaleDateString(undefined, { weekday: 'long' });
  }
  const extractDays = j => (j && j.success && (Array.isArray(j.data) ? j.data : (j.data && Array.isArray(j.data.days) ? j.data.days : null)));

  function selectedIDs(){
    const tableIds = [...tbody.querySelectorAll('.row-chk:checked')].map(ch => ch.closest('tr').getAttribute('data-id'));
    const masonryIds = [...document.querySelectorAll('#days-masonry .masonry-chk:checked')].map(ch => ch.value);
    return [...tableIds, ...masonryIds];
  }
  function updateBulkButton(){
    const count = selectedIDs().length;
    bulkBtn.classList.toggle('show', count >= 2);
  }

  function rebuild(days){
    if (!Array.isArray(days)) return;
    
    // Sort days by date (DDMMYYYY format ascending)
    // Convert DDMMYYYY to YYYYMMDD for proper chronological sorting
    const sortedDays = [...days].sort((a, b) => {
      const clean_a = String(a.date).replace(/\D/g, '');
      const clean_b = String(b.date).replace(/\D/g, '');
      
      // Convert DDMMYYYY to YYYYMMDD
      const dateA = clean_a.length === 8 ? clean_a.slice(4,8) + clean_a.slice(2,4) + clean_a.slice(0,2) : clean_a;
      const dateB = clean_b.length === 8 ? clean_b.slice(4,8) + clean_b.slice(2,4) + clean_b.slice(0,2) : clean_b;
      
      return dateA.localeCompare(dateB);
    });
    
    // Rebuild table
    const frag = document.createDocumentFragment();
    sortedDays.forEach(row=>{
      const tr=document.createElement('tr');
      tr.setAttribute('data-id', row.id);
      const dclean = String(row.date).replace(/\D/g,'');
      const ddisp  = fmtDate(dclean);
      tr.innerHTML = `
        <td><input type="checkbox" class="digical-checkbox row-chk"></td>
        <td>${ddisp}</td>
        <td>${weekdayName(ddisp)}</td>
        <td>${fmtTime(row.start_time)}</td>
        <td>${fmtTime(row.end_time)}</td>
        <td>
          <button type="button" class="digical-btn-action edit">Edit</button>
          <button type="button" class="digical-btn-action delete">Delete</button>
          <a href="${managePre}${row.id}&event_id=${eventId}" class="digical-btn-config">Configure Day</a>
        </td>`;
      frag.appendChild(tr);
    });
    tbody.innerHTML = '';
    tbody.appendChild(frag);
    chkAll.checked = false;
    updateBulkButton();

    // Rebuild masonry
    const masonryContainer = document.getElementById('days-masonry');
    if (masonryContainer) {
      masonryContainer.innerHTML = '';
      sortedDays.forEach(row => {
        const dclean = String(row.date).replace(/\D/g,'');
        const ddisp = fmtDate(dclean);
        const dayName = weekdayName(ddisp);
        
        const card = document.createElement('div');
        card.className = 'digical-day-card';
        card.setAttribute('data-id', row.id);
        card.innerHTML = `
          <input type="checkbox" class="digical-checkbox row-chk masonry-chk" value="${row.id}">
          <div class="digical-day-card-date">${ddisp}</div>
          <div class="digical-day-card-day">${dayName}</div>
          <div class="digical-day-card-times">
            ⏰ ${fmtTime(row.start_time)} - ${fmtTime(row.end_time)}
          </div>
          <div class="digical-day-card-actions">
            <button type="button" class="digical-btn-action edit">Edit</button>
            <button type="button" class="digical-btn-action delete">Delete</button>
            <a href="${managePre}${row.id}?event_id=${eventId}" class="digical-btn-config">Configure Day</a>
          </div>
        `;
        masonryContainer.appendChild(card);
      });
    }
  }

  async function post(body){
    try{
      const res = await fetch(ajaxurl, {
        method:'POST',
        credentials:'same-origin',
        headers:{'Content-Type':'application/x-www-form-urlencoded','Cache-Control':'no-store'},
        body:(body instanceof URLSearchParams) ? body.toString() : new URLSearchParams(body).toString()
      });
      const txt = await res.text();
      try { return JSON.parse(txt); } catch(e){ console.warn('Non-JSON response:', txt); return null; }
    }catch(err){ console.error(err); return null; }
  }

  // Refresh sidebar - requires page reload since menu is built server-side in admin_menu hook
  async function refreshSidebarMenu() {
    // Store current view preference before reload
    const currentView = document.getElementById('view-masonry-btn')?.classList.contains('active') ? 'masonry' : 'table';
    localStorage.setItem('digical_days_view', currentView);
    
    // Small delay to ensure localStorage is set, then reload
    setTimeout(() => {
      location.reload();
    }, 100);
  }

  // Reload page to refresh sidebar menu
  function reloadPage() {
    location.reload();
  }

  // Select-all / checkbox changes
  chkAll.addEventListener('change', ()=>{
    tbody.querySelectorAll('.row-chk').forEach(ch => ch.checked = chkAll.checked);
    updateBulkButton();
  });
  tbody.addEventListener('change', e=>{
    if (e.target.classList.contains('row-chk')) updateBulkButton();
  });

  // Masonry checkboxes
  document.getElementById('days-masonry')?.addEventListener('change', e=>{
    if (e.target.classList.contains('masonry-chk')) updateBulkButton();
  });

  // Bulk delete
  bulkBtn.addEventListener('click', ()=>{
    const ids = selectedIDs();
    if (ids.length < 1) return;
    if (!confirm('Delete selected days?')) return;
    // Save current view preference BEFORE reload
    const currentView = document.getElementById('view-masonry-btn')?.classList.contains('active') ? 'masonry' : 'table';
    localStorage.setItem('digical_days_view', currentView);
    const params = new URLSearchParams();
    params.append('action','digical_db_delete_days');
    params.append('nonce', nonce);
    params.append('event_id', eventId);
    ids.forEach(id => params.append('ids[]', id));
    post(params).then(j=>{
      const days = extractDays(j);
      if (days) {
        refreshSidebarMenu();
      }
      else if (j && j.data && j.data.message) alert(j.data.message);
    });
  });

  // Row actions (Table View)
  tbody.addEventListener('click', function(e){
    const btn = e.target.closest('button'); if (!btn) return;
    const tr  = btn.closest('tr');
    const id  = tr.getAttribute('data-id');

    if (btn.classList.contains('delete')) {
      if (!confirm('Delete this day?')) return;
      post({action:'digical_db_delete_day', id, nonce, event_id: eventId}).then(j=>{
        const days = extractDays(j);
        if (days) {
          refreshSidebarMenu();
        }
        else if (j && j.data && j.data.message) alert(j.data.message);
      });
      return;
    }

    if (btn.classList.contains('edit')) {
      const td = tr.querySelectorAll('td');
      const d  = td[1].textContent.trim();
      const s  = td[3].textContent.trim();
      const e2 = td[4].textContent.trim();
      td[1].innerHTML = `<input class="date-edit" value="${d}">`;
      td[3].innerHTML = `<input class="time-edit" value="${s}">`;
      td[4].innerHTML = `<input class="time-edit" value="${e2}">`;
      btn.textContent = 'Save';
      btn.classList.remove('edit');
      btn.classList.add('save');
      return;
    }

    if (btn.classList.contains('save')) {
      const td   = tr.querySelectorAll('td');
      const newD = td[1].querySelector('input').value.replace(/\./g,'');
      const newS = td[3].querySelector('input').value;
      const newE = td[4].querySelector('input').value;

      if (!validateDate(newD)) { alert('Invalid date'); return; }

      post({
        action:'digical_db_edit_day',
        id, nonce,
        day_date:newD,
        start_time:newS,
        end_time:newE,
        event_id: eventId
      }).then(j=>{
        const days = extractDays(j);
        if (days) {
          rebuild(days);
          // Stay in current view (table or masonry)
          const currentView = localStorage.getItem('digical_days_view') || 'table';
          if (currentView === 'masonry') {
            document.getElementById('view-masonry-btn')?.click();
          }
        }
        else if (j && j.data && j.data.message) alert(j.data.message);
      });
      return;
    }
  });

  // Masonry actions (Masonry View)
  const masonryContainer = document.getElementById('days-masonry');
  if (masonryContainer) {
    masonryContainer.addEventListener('click', function(e){
      const btn = e.target.closest('button, a');
      if (!btn) return;
      
      const card = btn.closest('.digical-day-card');
      if (!card) return;
      
      const id = card.getAttribute('data-id');

      // Delete button
      if (btn.classList.contains('delete')) {
        if (!confirm('Delete this day?')) return;
        // Save masonry view preference BEFORE calling refreshSidebarMenu which reloads
        localStorage.setItem('digical_days_view', 'masonry');
        post({action:'digical_db_delete_day', id, nonce, event_id: eventId}).then(j=>{
          const days = extractDays(j);
          if (days) {
            refreshSidebarMenu();
          }
          else if (j && j.data && j.data.message) alert(j.data.message);
        });
        return;
      }

      // Edit button
      if (btn.classList.contains('edit')) {
        const timesDiv = card.querySelector('.digical-day-card-times');
        const currentDate = card.querySelector('.digical-day-card-date').textContent.trim();
        const [startTime, endTime] = timesDiv.textContent.match(/(\d{1,2}:\d{2})/g) || ['', ''];
        
        timesDiv.innerHTML = `
          <input type="text" class="date-edit" value="${currentDate}" style="width: 100px; margin-right: 5px;">
          <input type="text" class="time-edit" value="${startTime}" style="width: 60px; margin-right: 5px;">
          <input type="text" class="time-edit" value="${endTime}" style="width: 60px;">
        `;
        
        btn.textContent = 'Save';
        btn.classList.remove('edit');
        btn.classList.add('save');
        return;
      }

      // Save button
      if (btn.classList.contains('save')) {
        const timesDiv = card.querySelector('.digical-day-card-times');
        const inputs = timesDiv.querySelectorAll('input');
        const newD = inputs[0].value.replace(/\./g, '');
        const newS = inputs[1].value;
        const newE = inputs[2].value;

        if (!validateDate(newD)) { alert('Invalid date'); return; }

        post({
          action:'digical_db_edit_day',
          id, nonce,
          day_date:newD,
          start_time:newS,
          end_time:newE,
          event_id: eventId
        }).then(j=>{
          const days = extractDays(j);
          if (days) {
            rebuild(days);
            // Stay in masonry view
            document.getElementById('view-masonry-btn')?.click();
          }
          else if (j && j.data && j.data.message) alert(j.data.message);
        });
        return;
      }

      // Configure Day link (anchor tag - just allow default behavior)
      if (btn.classList.contains('digical-btn-config')) {
        return; // Default link behavior will work
      }
    });
  }

  // View Toggle
  const tableViewBtn = document.getElementById('view-table-btn');
  const masonryViewBtn = document.getElementById('view-masonry-btn');
  const tableView = document.getElementById('days-table');
  const masonryView = document.getElementById('days-masonry');

  tableViewBtn?.addEventListener('click', () => {
    // Uncheck all checkboxes
    tbody.querySelectorAll('.row-chk').forEach(ch => ch.checked = false);
    document.querySelectorAll('#days-masonry .masonry-chk').forEach(ch => ch.checked = false);
    updateBulkButton();
    
    tableViewBtn.classList.add('active');
    masonryViewBtn.classList.remove('active');
    tableView.style.display = 'table';
    masonryView.classList.remove('show');
    localStorage.setItem('digical_days_view', 'table');
  });

  masonryViewBtn?.addEventListener('click', () => {
    // Uncheck all checkboxes
    tbody.querySelectorAll('.row-chk').forEach(ch => ch.checked = false);
    document.querySelectorAll('#days-masonry .masonry-chk').forEach(ch => ch.checked = false);
    updateBulkButton();
    
    masonryViewBtn.classList.add('active');
    tableViewBtn.classList.remove('active');
    tableView.style.display = 'none';
    masonryView.classList.add('show');
    localStorage.setItem('digical_days_view', 'masonry');
  });

  // Edit Modal Handlers
  const modal = document.getElementById('edit-modal');
  const editCancel = document.getElementById('edit-cancel');
  const editSave = document.getElementById('edit-save');
  
  editCancel?.addEventListener('click', () => {
    modal.style.display = 'none';
  });
  
  modal?.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.style.display = 'none';
    }
  });
  
  editSave?.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    const id = modal.getAttribute('data-id');
    const newDate = document.getElementById('edit-date').value.trim();
    const newStart = document.getElementById('edit-start').value.trim();
    const newEnd = document.getElementById('edit-end').value.trim();
    
    if (!newDate || !newStart || !newEnd) {
      alert('All fields are required');
      return;
    }
    
    if (!validateDate(newDate)) {
      alert('Invalid date format. Please use DDMMYYYY');
      return;
    }
    
    post({
      action:'digical_db_edit_day',
      id,
      day_date: newDate,
      start_time: newStart,
      end_time: newEnd,
      nonce,
      event_id: eventId
    }).then(j=>{
      const days = extractDays(j);
      if (days) {
        rebuild(days);
        modal.style.display = 'none';
      }
      else if (j && j.data && j.data.message) alert(j.data.message);
    });
  });
  
  document.getElementById('edit-end')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      editSave.click();
    }
  });

  // Create
  form.addEventListener('submit', function(e){
    e.preventDefault();
    if (!validateDate(form.day_date.value)) { alert('Invalid date'); return; }
    // Save current view preference BEFORE reload
    const currentView = document.getElementById('view-masonry-btn')?.classList.contains('active') ? 'masonry' : 'table';
    localStorage.setItem('digical_days_view', currentView);
    // Set flag to focus date field after reload
    sessionStorage.setItem('digical_focus_date_field', 'true');
    post({
      action:'digical_db_add_day',
      nonce,
      day_date: form.day_date.value,
      start_time: form.start_time.value,
      end_time: form.end_time.value,
      event_id: eventId
    }).then(j=>{
      const days = extractDays(j);
      if (days) { 
        rebuild(days);
        refreshSidebarMenu();
      }
      else if (j && j.data && j.data.message) alert(j.data.message);
    });
  });

  // Initial load
  const initialDays = <?php echo json_encode($rows); ?>;
  if (initialDays && Array.isArray(initialDays)) {
    rebuild(initialDays);
  }

  // Restore view preference from localStorage, default to table if not set
  const savedView = localStorage.getItem('digical_days_view');
  if (savedView === 'masonry') {
    masonryViewBtn?.click();
  } else {
    tableViewBtn?.click();
  }

  // After reload from add day, focus the date field
  if (sessionStorage.getItem('digical_focus_date_field')) {
    sessionStorage.removeItem('digical_focus_date_field');
    form.reset();
    form.day_date.focus();
  }
});
</script>