<?php
/**
 * DigiCal Days AJAX & Database (FIXED - Event ID filtering)
 * FILE: digi-cal/admin/days-ajax-db.php
 */

if (!defined('ABSPATH')) exit;

/**
 * Get all days for active event (FIXED - with event_id filter & proper date sorting)
 * Sorts by YYYY-MM-DD format (converts DDMMYYYY to YYYYMMDD for proper chronological order)
 */
function digical_days_all_rows() {
    global $wpdb;
    
    // Get active event ID
    $event_id = digical_get_active_event_id();
    if (!$event_id) {
        return [];
    }
    
    $table = $wpdb->prefix . 'digical_days';
    $query = $wpdb->prepare(
        "SELECT * FROM $table WHERE event_id = %s ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC, start_time ASC",
        $event_id
    );
    
    return $wpdb->get_results($query, ARRAY_A);
}

/**
 * Ensure days table exists
 */
function digical_days_ensure_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'digical_days';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS `$table` (
        `id` varchar(100) NOT NULL PRIMARY KEY,
        `event_id` varchar(100) NOT NULL,
        `date` varchar(8) NOT NULL,
        `start_time` varchar(5) NOT NULL,
        `end_time` varchar(5) NOT NULL,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        KEY `idx_event_date` (`event_id`, `date`),
        KEY `idx_event_id` (`event_id`),
        FOREIGN KEY (`event_id`) REFERENCES {$wpdb->prefix}digical_events(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * AJAX: Get all days for event
 */
add_action('wp_ajax_digical_db_get_days', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : digical_get_active_event_id();
    
    if (!$event_id) {
        wp_send_json_error('No active event');
        return;
    }
    
    $table = $wpdb->prefix . 'digical_days';
    $days = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC, start_time ASC", $event_id),
        ARRAY_A
    );
    
    wp_send_json_success(['days' => $days]);
});

/**
 * AJAX: Add day
 */
add_action('wp_ajax_digical_db_add_day', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : digical_get_active_event_id();
    
    if (!$event_id) {
        wp_send_json_error('No active event');
        return;
    }
    
    $id = 'day_' . substr(md5(uniqid()), 0, 20);
    $date = sanitize_text_field($_POST['day_date'] ?? '');
    $start_time = sanitize_text_field($_POST['start_time'] ?? '');
    $end_time = sanitize_text_field($_POST['end_time'] ?? '');
    
    if (!$date) {
        wp_send_json_error('Date is required');
        return;
    }
    
    $table = $wpdb->prefix . 'digical_days';
    $result = $wpdb->insert(
        $table,
        ['id' => $id, 'event_id' => $event_id, 'date' => $date, 'start_time' => $start_time, 'end_time' => $end_time],
        ['%s', '%s', '%s', '%s', '%s']
    );
    
    if ($result === false) {
        wp_send_json_error('Database error: ' . $wpdb->last_error);
        return;
    }
    
    $days = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC, start_time ASC", $event_id),
        ARRAY_A
    );
    
    wp_send_json_success(['days' => $days, 'message' => 'Day added']);
});

/**
 * AJAX: Delete day
 */
add_action('wp_ajax_digical_db_delete_day', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : digical_get_active_event_id();
    $id = sanitize_text_field($_POST['id'] ?? '');
    
    if (!$id) {
        wp_send_json_error('Day ID required');
        return;
    }
    
    $table = $wpdb->prefix . 'digical_days';
    $wpdb->delete($table, ['id' => $id, 'event_id' => $event_id], ['%s', '%s']);
    
    $days = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC, start_time ASC", $event_id),
        ARRAY_A
    );
    
    wp_send_json_success(['days' => $days, 'message' => 'Day deleted']);
});

/**
 * AJAX: Delete multiple days
 */
add_action('wp_ajax_digical_db_delete_days', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : digical_get_active_event_id();
    $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];
    $ids = array_map('sanitize_text_field', $ids);
    
    if (empty($ids)) {
        wp_send_json_error('No days selected');
        return;
    }
    
    $table = $wpdb->prefix . 'digical_days';
    foreach ($ids as $id) {
        $wpdb->delete($table, ['id' => $id, 'event_id' => $event_id], ['%s', '%s']);
    }
    
    $days = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC, start_time ASC", $event_id),
        ARRAY_A
    );
    
    wp_send_json_success(['days' => $days, 'message' => count($ids) . ' day(s) deleted']);
});

/**
 * AJAX: Edit day
 */
add_action('wp_ajax_digical_db_edit_day', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : digical_get_active_event_id();
    $id = sanitize_text_field($_POST['id'] ?? '');
    $date = sanitize_text_field($_POST['day_date'] ?? '');
    $start_time = sanitize_text_field($_POST['start_time'] ?? '');
    $end_time = sanitize_text_field($_POST['end_time'] ?? '');
    
    if (!$id || !$date) {
        wp_send_json_error('ID and date are required');
        return;
    }
    
    $table = $wpdb->prefix . 'digical_days';
    $wpdb->update(
        $table,
        ['date' => $date, 'start_time' => $start_time, 'end_time' => $end_time],
        ['id' => $id, 'event_id' => $event_id],
        ['%s', '%s', '%s'],
        ['%s', '%s']
    );
    
    $days = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC, start_time ASC", $event_id),
        ARRAY_A
    );
    
    wp_send_json_success(['days' => $days, 'message' => 'Day updated']);
});

/**
 * AJAX: Get sidebar menu items (for auto-refresh)
 */
add_action('wp_ajax_digical_get_sidebar_menu', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
    }
    
    global $wpdb;
    $event_id = digical_get_active_event_id();
    
    if (!$event_id) {
        wp_send_json_error('No active event');
        return;
    }
    
    $table = $wpdb->prefix . 'digical_days';
    $days = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id, date FROM $table WHERE event_id = %s ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC",
            $event_id
        ),
        ARRAY_A
    );
    
    $menu_items = [];
    foreach ($days as $day) {
        $dateLabel = preg_match('/^(\d{2})(\d{2})(\d{4})$/', (string)$day['date'], $m)
            ? "{$m[1]}.{$m[2]}.{$m[3]}"
            : esc_html((string)$day['date']);
        
        $menu_items[] = [
            'id' => $day['id'],
            'date' => $dateLabel,
            'slug' => 'digical-day-' . sanitize_key($day['id'])
        ];
    }
    
    wp_send_json_success(['menu_items' => $menu_items]);
});