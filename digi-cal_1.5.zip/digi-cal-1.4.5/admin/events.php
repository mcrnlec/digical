<?php
/**
 * DigiCal Events Management UI (FIXED - with proper event_id in links)
 * 
 * FILE LOCATION: digi-cal/admin/events.php
 */

if (!defined('ABSPATH')) exit;

$events = digical_events_all_rows();
$active_event_id = digical_get_active_event_id();

// Generate nonce once
$nonce = wp_create_nonce('digical_event_nonce');
?>

<style>
/* ===== Events Management - Modern Professional Styling ===== */

.digical-events-container {
    background: transparent;
    padding: 0;
}

.digical-events-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding: 0;
}

.digical-events-header h2 {
    margin: 0;
    font-size: 28px;
    font-weight: 700;
    color: #2c3e50;
}

#new-event-btn {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%) !important;
    color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 12px 32px !important;
    font-size: 15px !important;
    font-weight: 700 !important;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    box-shadow: 0 2px 8px rgba(34, 113, 177, 0.2);
    text-decoration: none !important;
}

#new-event-btn:hover {
    box-shadow: 0 4px 16px rgba(34, 113, 177, 0.3) !important;
    transform: translateY(-2px) !important;
}

.digical-events-bar {
    display: flex;
    align-items: center;
    gap: 16px;
    margin: 20px 0 24px 0;
}

.digical-events-bar .bulk-btn {
    display: none;
}

.digical-events-bar .bulk-btn.show {
    display: inline-block;
}

#bulk-delete-events {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%) !important;
    color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 12px 24px !important;
    font-size: 14px !important;
    font-weight: 700 !important;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.2);
}

#bulk-delete-events:hover {
    box-shadow: 0 4px 16px rgba(231, 76, 60, 0.3) !important;
    transform: translateY(-2px) !important;
}

/* View Toggle Buttons */
.view-toggle-buttons {
    display: flex;
    gap: 12px;
    margin-bottom: 24px;
}

.view-toggle-buttons button {
    background: linear-gradient(135deg, #f8fafc 0%, #f0f4f8 100%);
    border: 2px solid #e0e6ed;
    border-radius: 8px;
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    color: #2c3e50;
}

.view-toggle-buttons button:hover {
    border-color: #2271b1;
    color: #2271b1;
}

.view-toggle-buttons button.active {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    border-color: #2271b1;
    color: white;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.2);
}

/* Table Styles */
.digical-events-table {
    border-collapse: collapse;
    margin-top: 0;
    font-size: 15px;
    table-layout: auto;
    width: 100%;
    background: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    border: 1px solid #e0e6ed;
}

.digical-events-table th {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    color: #fff;
    text-align: left;
    font-weight: 700;
    font-size: 12px;
    border: none;
    padding: 14px 16px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.digical-events-table th:first-child {
    padding-left: 16px;
}

.digical-events-table th:last-child {
    text-align: center;
}

.digical-events-table td {
    background: #fff;
    padding: 14px 16px;
    border: none;
    border-bottom: 1px solid #ecf0f1;
    vertical-align: middle;
    font-size: 14px;
    color: #2c3e50;
    font-weight: 500;
}

.digical-events-table tbody tr:last-child td {
    border-bottom: none;
}

.digical-events-table tbody tr:hover td {
    background: #f8fafc;
}

.digical-events-table input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: #2271b1;
}

/* Masonry Grid */
#events-masonry {
    display: none;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

#events-masonry.show {
    display: grid;
}

#events-table {
    display: table;
}

#events-table.hidden {
    display: none;
}

.event-card {
    background: white;
    border: 1px solid #e0e6ed;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
}

.event-card:hover {
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

.event-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
}

.event-card-title {
    font-size: 16px;
    font-weight: 700;
    color: #2c3e50;
    margin: 0 0 4px 0;
    word-break: break-word;
}

.event-card-slug {
    font-size: 12px;
    color: #7f8c8d;
    margin-bottom: 8px;
}

.event-card-status {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.event-card-status.draft {
    background: #ecf0f1;
    color: #7f8c8d;
}

.event-card-status.published {
    background: #d4edda;
    color: #155724;
}

.event-card-dates {
    font-size: 13px;
    color: #5a6c7d;
    margin: 12px 0;
    line-height: 1.6;
}

.event-card-created {
    font-size: 12px;
    color: #95a5a6;
    margin-top: 8px;
    padding-top: 12px;
    border-top: 1px solid #ecf0f1;
}

.event-card-actions {
    display: flex;
    gap: 6px;
    margin-top: auto;
    padding-top: 12px;
    flex-wrap: wrap;
}

/* Event Row Actions */
.event-row-actions {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}

.digical-event-btn {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    color: #fff;
    border: none;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-block;
    box-shadow: 0 2px 6px rgba(34, 113, 177, 0.15);
    text-decoration: none;
    line-height: 1.4;
    white-space: nowrap;
}

.digical-event-btn:hover {
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.25);
    transform: translateY(-2px);
    color: #fff;
}

.digical-event-btn.delete {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    box-shadow: 0 2px 6px rgba(231, 76, 60, 0.15);
}

.digical-event-btn.delete:hover {
    box-shadow: 0 4px 12px rgba(231, 76, 60, 0.25);
}

.digical-event-btn.manage {
    background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
    box-shadow: 0 2px 6px rgba(39, 174, 96, 0.15);
}

.digical-event-btn.manage:hover {
    box-shadow: 0 4px 12px rgba(39, 174, 96, 0.25);
}

/* Status Badge */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-draft {
    background: #ecf0f1;
    color: #7f8c8d;
}

.status-published {
    background: #d4edda;
    color: #155724;
}

/* Modal Styles */
.digical-modal {
    display: none;
    position: fixed;
    z-index: 10000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
}

.digical-modal.show {
    display: flex !important;
    align-items: center;
    justify-content: center;
}

.digical-modal .modal-content {
    background-color: white;
    padding: 25px;
    border-radius: 12px;
    max-width: 480px;
    width: 85%;
    max-height: 85vh;
    overflow-y: auto;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.digical-modal .modal-content h2 {
    margin-top: 0;
    margin-bottom: 8px;
    color: #2c3e50;
    font-size: 16px;
}

.digical-modal .close {
    float: right;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    background: none;
    border: none;
    color: #7f8c8d;
    padding: 0;
    margin: -5px -5px 0 0;
    line-height: 1;
}

.digical-modal .close:hover {
    color: #2c3e50;
}

.digical-modal .form-table {
    width: 100%;
    border-collapse: collapse;
}

.digical-modal .form-table tr {
    display: flex;
    flex-direction: column;
    margin-bottom: 8px;
}

.digical-modal .form-table th {
    text-align: left;
    margin-bottom: 5px;
    font-weight: 600;
    color: #2c3e50;
    font-size: 12px;
    padding: 0;
}

.digical-modal .form-table td {
    border: none;
    padding: 0;
}

.digical-modal input[type="text"],
.digical-modal textarea,
.digical-modal select {
    width: 100%;
    padding: 7px 10px;
    font-size: 13px;
    border: 1px solid #d1d8e0;
    border-radius: 5px;
    box-sizing: border-box;
    font-family: inherit;
}

.digical-modal textarea {
    height: 50px;
    resize: vertical;
}

.digical-modal input[type="text"]:focus,
.digical-modal textarea:focus,
.digical-modal select:focus {
    outline: none;
    border-color: #2271b1;
    box-shadow: 0 0 0 3px rgba(34, 113, 177, 0.1);
}

.digical-modal .modal-actions {
    display: flex;
    gap: 10px;
    margin-top: 12px;
}

.digical-modal .modal-actions button {
    flex: 1;
    padding: 8px;
    border: none;
    border-radius: 5px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
}

.digical-modal .modal-actions button[type="button"]:first-child {
    background: linear-gradient(135deg, #2271b1 0%, #1a5a8e 100%);
    color: white;
}

.digical-modal .modal-actions button[type="button"]:first-child:hover {
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.25);
    transform: translateY(-2px);
}

.digical-modal .modal-actions button[type="button"]:last-child {
    background: #ecf0f1;
    color: #7f8c8d;
}

.digical-modal .modal-actions button[type="button"]:last-child:hover {
    background: #d1d8e0;
}

/* Responsive */
@media (max-width: 768px) {
    .digical-events-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }

    #new-event-btn {
        width: 100%;
        padding: 10px 16px !important;
        font-size: 14px !important;
    }

    .digical-events-bar {
        flex-direction: column;
    }

    .digical-view-toggle {
        margin-left: 0;
        width: 100%;
    }

    .digical-view-toggle .digical-view-btn {
        flex: 1;
    }

    .digical-events-table {
        font-size: 13px;
    }

    .digical-events-table td,
    .digical-events-table th {
        padding: 10px 8px;
    }

    .digical-event-btn {
        padding: 6px 10px;
        font-size: 11px;
    }

    .event-row-actions {
        flex-direction: column;
        gap: 4px;
    }

    .event-row-actions a {
        display: block;
        text-align: center;
    }

    #events-masonry {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="digical-events-container">
    <div class="digical-events-header">
        <h2>Events</h2>
        <button id="new-event-btn" class="button button-primary">+ New Event</button>
    </div>

    <div class="view-toggle-buttons">
        <button id="view-table-btn" class="active">📊 Table</button>
        <button id="view-masonry-btn">📋 Masonry</button>
    </div>

    <div class="digical-events-bar">
        <button id="bulk-delete-events" class="bulk-btn digical-bulk">🗑️ Delete Selected</button>
    </div>

    <!-- Table View -->
    <table id="events-table" class="digical-events-table">
        <thead>
            <tr>
                <th width="30"><input type="checkbox" id="select-all-events"></th>
                <th>Name</th>
                <th>Slug</th>
                <th>Status</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Created</th>
                <th style="text-align: center;">Actions</th>
            </tr>
        </thead>
        <tbody id="events-table-body">
            <?php foreach ( $events as $event ): ?>
                <tr class="event-row" data-id="<?php echo esc_attr( $event['id'] ); ?>">
                    <td><input type="checkbox" class="event-checkbox" value="<?php echo esc_attr( $event['id'] ); ?>"></td>
                    <td><?php echo esc_html( $event['name'] ); ?></td>
                    <td><?php echo esc_html( $event['slug'] ); ?></td>
                    <td><span class="status-badge status-<?php echo esc_attr( $event['status'] ); ?>"><?php echo esc_html( ucfirst( $event['status'] ) ); ?></span></td>
                    <td><?php echo $event['start_date'] ? esc_html( substr( $event['start_date'], 0, 2 ) . '.' . substr( $event['start_date'], 2, 2 ) . '.' . substr( $event['start_date'], 4 ) ) : '—'; ?></td>
                    <td><?php echo $event['end_date'] ? esc_html( substr( $event['end_date'], 0, 2 ) . '.' . substr( $event['end_date'], 2, 2 ) . '.' . substr( $event['end_date'], 4 ) ) : '—'; ?></td>
                    <td><?php echo esc_html( date_format( date_create( $event['created_at'] ), 'd.m.Y H:i' ) ); ?></td>
                    <td style="text-align: center;">
                        <div class="event-row-actions">
                            <a href="#" class="digical-event-btn btn-edit-event" data-id="<?php echo esc_attr( $event['id'] ); ?>">Edit</a>
                            <a href="#" class="digical-event-btn btn-copy-event" data-id="<?php echo esc_attr( $event['id'] ); ?>">Copy</a>
                            <a href="#" class="digical-event-btn delete btn-delete-event" data-id="<?php echo esc_attr( $event['id'] ); ?>">Delete</a>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=digical-dashboard&event_id=' . urlencode( $event['id'] ) ) ); ?>" class="digical-event-btn manage">Manage</a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Masonry View -->
    <div id="events-masonry">
        <?php foreach ( $events as $event ): ?>
            <div class="event-card" data-id="<?php echo esc_attr( $event['id'] ); ?>">
                <div class="event-card-header">
                    <div style="flex: 1;">
                        <h3 class="event-card-title"><?php echo esc_html( $event['name'] ); ?></h3>
                        <div class="event-card-slug"><?php echo esc_html( $event['slug'] ); ?></div>
                    </div>
                    <span class="event-card-status <?php echo esc_attr( $event['status'] ); ?>"><?php echo esc_html( ucfirst( $event['status'] ) ); ?></span>
                </div>

                <div class="event-card-dates">
                    <?php if ($event['start_date']): ?>
                        <strong>Start:</strong> <?php echo esc_html( substr( $event['start_date'], 0, 2 ) . '.' . substr( $event['start_date'], 2, 2 ) . '.' . substr( $event['start_date'], 4 ) ); ?><br>
                    <?php endif; ?>
                    <?php if ($event['end_date']): ?>
                        <strong>End:</strong> <?php echo esc_html( substr( $event['end_date'], 0, 2 ) . '.' . substr( $event['end_date'], 2, 2 ) . '.' . substr( $event['end_date'], 4 ) ); ?>
                    <?php endif; ?>
                </div>

                <div class="event-card-created">
                    Created: <?php echo esc_html( date_format( date_create( $event['created_at'] ), 'd.m.Y H:i' ) ); ?>
                </div>

                <div class="event-card-actions">
                    <a href="#" class="digical-event-btn btn-edit-event" data-id="<?php echo esc_attr( $event['id'] ); ?>">Edit</a>
                    <a href="#" class="digical-event-btn btn-copy-event" data-id="<?php echo esc_attr( $event['id'] ); ?>">Copy</a>
                    <a href="#" class="digical-event-btn delete btn-delete-event" data-id="<?php echo esc_attr( $event['id'] ); ?>">Delete</a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=digical-dashboard&event_id=' . urlencode( $event['id'] ) ) ); ?>" class="digical-event-btn manage">Manage</a>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (empty($events)): ?>
            <div style="grid-column: 1 / -1; text-align: center; color: #999; padding: 40px;">No events yet</div>
        <?php endif; ?>
    </div>
</div>

<!-- New/Edit Event Modal -->
<div id="event-modal" style="display:none;" class="digical-modal">
    <div class="modal-content">
        <button class="close" id="close-event-modal">&times;</button>
        <h2 id="modal-title">New Event</h2>
        
        <form id="event-form">
            <table class="form-table">
                <tr>
                    <th><label for="event-name">Event Name</label></th>
                    <td><input type="text" id="event-name" name="name" required style="width:100%;"></td>
                </tr>
                <tr>
                    <th><label for="event-slug">Slug</label></th>
                    <td><input type="text" id="event-slug" name="slug" style="width:100%;"></td>
                </tr>
                <tr>
                    <th><label for="event-desc">Description</label></th>
                    <td><textarea id="event-desc" name="description" style="width:100%; height:100px;"></textarea></td>
                </tr>
                <tr>
                    <th><label for="event-start">Start Date (DDMMYYYY)</label></th>
                    <td><input type="text" id="event-start" name="start_date" placeholder="06112025" style="width:100%;"></td>
                </tr>
                <tr>
                    <th><label for="event-end">End Date (DDMMYYYY)</label></th>
                    <td><input type="text" id="event-end" name="end_date" placeholder="08112025" style="width:100%;"></td>
                </tr>
                <tr>
                    <th><label for="event-status">Status</label></th>
                    <td>
                        <select id="event-status" name="status">
                            <option value="draft">Draft</option>
                            <option value="published">Published</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <input type="hidden" id="event-id" name="id">
            <p>
                <button type="submit" class="button button-primary">Save Event</button>
                <button type="button" class="button" id="cancel-event">Cancel</button>
            </p>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Store nonce globally
    var eventNonce = '<?php echo esc_js($nonce); ?>';
    
    // View switching logic
    let CURRENT_VIEW = localStorage.getItem('digical_events_view') || 'table';
    
    function setView(view) {
        CURRENT_VIEW = view;
        localStorage.setItem('digical_events_view', view);
        
        if (view === 'table') {
            document.getElementById('view-table-btn').classList.add('active');
            document.getElementById('view-masonry-btn').classList.remove('active');
            document.getElementById('events-table').classList.remove('hidden');
            document.getElementById('events-masonry').classList.remove('show');
        } else {
            document.getElementById('view-table-btn').classList.remove('active');
            document.getElementById('view-masonry-btn').classList.add('active');
            document.getElementById('events-table').classList.add('hidden');
            document.getElementById('events-masonry').classList.add('show');
        }
    }
    
    // Initialize view on page load
    setView(CURRENT_VIEW);
    
    // View toggle buttons
    document.getElementById('view-table-btn').addEventListener('click', function(e) {
        e.preventDefault();
        setView('table');
    });
    
    document.getElementById('view-masonry-btn').addEventListener('click', function(e) {
        e.preventDefault();
        setView('masonry');
    });
    
    // Show new event modal
    $('#new-event-btn').on('click', function() {
        $('#event-id').val('');
        $('#event-form')[0].reset();
        $('#modal-title').text('New Event');
        document.getElementById('event-modal').classList.add('show');
    });

    // Auto-generate slug from event name
    $('#event-name').on('keyup blur', function() {
        var name = $(this).val();
        if (name) {
            var slug = name
                .toLowerCase()
                .trim()
                .replace(/[^\w\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .replace(/^-+|-+$/g, '');
            
            $('#event-slug').val(slug);
        }
    });

    // Close modal
    $('#close-event-modal, #cancel-event').on('click', function() {
        document.getElementById('event-modal').classList.remove('show');
        $('#event-modal').removeData('copy-mode').removeData('source-id');
    });

    // Save event
    $('#event-form').on('submit', function(e) {
        e.preventDefault();
        
        var isCopyMode = $('#event-modal').data('copy-mode') === 'true';
        var sourceId = $('#event-modal').data('source-id');
        
        if (isCopyMode) {
            $.post(ajaxurl, {
                action: 'digical_event_copy',
                source_id: sourceId,
                new_name: $('#event-name').val(),
                new_slug: $('#event-slug').val(),
                nonce: eventNonce
            }, function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (response.data || 'Unknown error'));
                }
            }, 'json').fail(function(jqXHR) {
                alert('AJAX Error: ' + jqXHR.status + ' ' + jqXHR.statusText);
            });
        } else {
            var data = {
                action: 'digical_event_save',
                id: $('#event-id').val(),
                name: $('#event-name').val(),
                slug: $('#event-slug').val(),
                description: $('#event-desc').val(),
                start_date: $('#event-start').val(),
                end_date: $('#event-end').val(),
                status: $('#event-status').val(),
                nonce: eventNonce
            };

            $.post(ajaxurl, data, function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (response.data || 'Unknown error'));
                    console.error('Response:', response);
                }
            }).fail(function(jqXHR) {
                alert('AJAX Error: ' + jqXHR.status + ' ' + jqXHR.statusText);
                console.error('AJAX Error:', jqXHR);
            });
        }
        
        $('#event-modal').removeData('copy-mode').removeData('source-id');
    });

    // Delete event
    $(document).on('click', '.btn-delete-event', function(e) {
        e.preventDefault();
        if (confirm('Are you sure?')) {
            var event_id = $(this).data('id');
            $.post(ajaxurl, {
                action: 'digical_event_delete',
                id: event_id,
                nonce: eventNonce
            }, function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (response.data || 'Unknown error'));
                }
            }).fail(function(jqXHR) {
                alert('AJAX Error: ' + jqXHR.status + ' ' + jqXHR.statusText);
            });
        }
    });

    // Edit event - modal popup for both table and masonry
    $(document).on('click', '.btn-edit-event', function(e) {
        e.preventDefault();
        var event_id = $(this).closest('.event-row, .event-card').data('id');
        var $container = $(this).closest('.event-row, .event-card');
        
        // Get event data
        var name, slug, status, start_date, end_date;
        
        if ($container.hasClass('event-row')) {
            // Table view
            var $tds = $container.find('td');
            name = $tds.eq(1).text().trim();
            slug = $tds.eq(2).text().trim();
            status = $tds.eq(3).find('.status-badge').text().trim().toLowerCase();
            start_date = $tds.eq(4).text().trim();
            end_date = $tds.eq(5).text().trim();
        } else {
            // Masonry view
            name = $container.find('.event-card-title').text().trim();
            slug = $container.find('.event-card-slug').text().trim();
            status = $container.find('.event-card-status').text().trim().toLowerCase();
            
            // Extract dates from card
            var dateText = $container.find('.event-card-dates').text();
            var startMatch = dateText.match(/Start:\s*(\d{2}\.\d{2}\.\d{4})/);
            var endMatch = dateText.match(/End:\s*(\d{2}\.\d{2}\.\d{4})/);
            start_date = startMatch ? startMatch[1] : '';
            end_date = endMatch ? endMatch[1] : '';
        }
        
        function dateToInput(dateStr) {
            if (dateStr === '—' || !dateStr) return '';
            return dateStr.replace(/\./g, '');
        }
        
        start_date = dateToInput(start_date);
        end_date = dateToInput(end_date);
        
        // Populate modal
        $('#event-id').val(event_id);
        $('#event-name').val(name);
        $('#event-slug').val(slug);
        $('#event-status').val(status);
        $('#event-start').val(start_date);
        $('#event-end').val(end_date);
        $('#modal-title').text('Edit Event');
        
        // Show modal
        document.getElementById('event-modal').classList.add('show');
    });

    // Copy event
    $(document).on('click', '.btn-copy-event', function(e) {
        e.preventDefault();
        var event_id = $(this).data('id');
        var $container = $(this).closest('.event-row, .event-card');
        var eventName = $container.find('.event-card-title, td').eq(1).text().trim();
        
        $('#event-id').val('');
        $('#event-form')[0].reset();
        $('#modal-title').text('Copy Event: ' + eventName);
        $('#event-name').val(eventName + ' (copy)');
        
        var slugName = (eventName + ' (copy)')
            .toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-+|-+$/g, '');
        $('#event-slug').val(slugName);
        
        $('#event-modal').data('copy-mode', 'true').data('source-id', event_id);
        document.getElementById('event-modal').classList.add('show');
    });

    // Bulk select all
    $('#select-all-events').on('change', function() {
        $('.event-checkbox').prop('checked', this.checked);
        updateBulkDelete();
    });

    // Update bulk delete button
    function updateBulkDelete() {
        var checked = $('.event-checkbox:checked').length;
        if (checked > 0) {
            $('#bulk-delete-events').show();
        } else {
            $('#bulk-delete-events').hide();
        }
    }

    $('.event-checkbox').on('change', updateBulkDelete);

    // Bulk delete
    $('#bulk-delete-events').on('click', function() {
        if (!confirm('Delete all selected events? This cannot be undone.')) return;
        
        var ids = [];
        $('.event-checkbox:checked').each(function() {
            ids.push($(this).val());
        });

        $.post(ajaxurl, {
            action: 'digical_event_bulk_delete',
            ids: ids,
            nonce: eventNonce
        }, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert('Error: ' + (response.data || 'Unknown error'));
            }
        }).fail(function(jqXHR) {
            alert('AJAX Error: ' + jqXHR.status + ' ' + jqXHR.statusText);
        });
    });
});
</script>