<?php
/**
 * DigiCal Events AJAX & Database Handlers (FIXED)
 * 
 * FILE LOCATION: digi-cal/admin/events-ajax-db.php
 * 
 * COPY THIS ENTIRE FILE AND CREATE IT IN YOUR PLUGIN
 * 
 * ADD THIS LINE TO digi-cal.php:
 * require_once DIGICAL_PATH . 'admin/events-ajax-db.php';
 */

if (!defined('ABSPATH')) exit;

/**
 * Save event (create or update)
 */
add_action('wp_ajax_digical_event_save', function() {
    // Check nonce
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'digical_event_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
        return;
    }

    global $wpdb;
    
    $id = isset($_POST['id']) && $_POST['id'] ? sanitize_text_field($_POST['id']) : digical_generate_event_id();
    $name = sanitize_text_field($_POST['name'] ?? '');
    $slug = sanitize_title($_POST['slug'] ?? $name);
    $description = wp_kses_post($_POST['description'] ?? '');
    $start_date = sanitize_text_field($_POST['start_date'] ?? '');
    $end_date = sanitize_text_field($_POST['end_date'] ?? '');
    $status = in_array($_POST['status'] ?? 'draft', ['draft', 'published']) ? $_POST['status'] : 'draft';

    if (empty($name)) {
        wp_send_json_error('Event name is required');
        return;
    }

    $table = $wpdb->prefix . 'digical_events';
    
    // Check if updating existing
    $existing = $wpdb->get_row(
        $wpdb->prepare("SELECT id FROM $table WHERE id = %s", $id),
        ARRAY_A
    );
    
    if ($existing) {
        // Update
        $result = $wpdb->update(
            $table,
            compact('name', 'slug', 'description', 'start_date', 'end_date', 'status'),
            ['id' => $id],
            ['%s', '%s', '%s', '%s', '%s', '%s'],
            ['%s']
        );
        
        if ($result === false) {
            wp_send_json_error('Database error: ' . $wpdb->last_error);
            return;
        }
    } else {
        // Insert
        $result = $wpdb->insert(
            $table,
            compact('id', 'name', 'slug', 'description', 'start_date', 'end_date', 'status') + ['created_by' => get_current_user_id()],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d']
        );
        
        if ($result === false) {
            wp_send_json_error('Database error: ' . $wpdb->last_error);
            return;
        }
    }

    wp_send_json_success(['id' => $id, 'message' => 'Event saved successfully']);
});

/**
 * Delete event (cascades all related data)
 */
add_action('wp_ajax_digical_event_delete', function() {
    // Check nonce
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'digical_event_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
        return;
    }

    global $wpdb;
    $id = sanitize_text_field($_POST['id'] ?? '');
    
    if (empty($id)) {
        wp_send_json_error('Event ID is required');
        return;
    }
    
    // Delete event and cascade
    $wpdb->delete($wpdb->prefix . 'digical_events', ['id' => $id], ['%s']);
    $wpdb->delete($wpdb->prefix . 'digical_days', ['event_id' => $id], ['%s']);
    $wpdb->delete($wpdb->prefix . 'digical_venues', ['event_id' => $id], ['%s']);
    $wpdb->delete($wpdb->prefix . 'digical_speakers', ['event_id' => $id], ['%s']);
    $wpdb->delete($wpdb->prefix . 'digical_titles', ['event_id' => $id], ['%s']);
    $wpdb->delete($wpdb->prefix . 'digical_roles', ['event_id' => $id], ['%s']);

    wp_send_json_success(['message' => 'Event deleted successfully']);
});

/**
 * Copy event (deep copy all related data)
 */
add_action('wp_ajax_digical_event_copy', function() {
    // Check nonce
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'digical_event_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
        return;
    }

    $source_id = sanitize_text_field($_POST['source_id'] ?? '');
    $new_name = sanitize_text_field($_POST['new_name'] ?? '');
    $new_slug = sanitize_text_field($_POST['new_slug'] ?? '');
    
    if (empty($source_id) || empty($new_name)) {
        wp_send_json_error('Source event ID and new name are required');
        return;
    }
    
    $new_id = digical_event_copy($source_id, $new_name, $new_slug ?: null);

    if ($new_id) {
        wp_send_json_success(['id' => $new_id, 'message' => 'Event copied successfully']);
    } else {
        wp_send_json_error('Failed to copy event');
    }
});

/**
 * Bulk delete events
 */
add_action('wp_ajax_digical_event_bulk_delete', function() {
    // Check nonce
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'digical_event_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
        return;
    }

    global $wpdb;
    $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];
    
    if (empty($ids)) {
        wp_send_json_error('No events selected');
        return;
    }
    
    $ids = array_map('sanitize_text_field', $ids);

    foreach ($ids as $id) {
        // Delete event and cascade
        $wpdb->delete($wpdb->prefix . 'digical_events', ['id' => $id], ['%s']);
        $wpdb->delete($wpdb->prefix . 'digical_days', ['event_id' => $id], ['%s']);
        $wpdb->delete($wpdb->prefix . 'digical_venues', ['event_id' => $id], ['%s']);
        $wpdb->delete($wpdb->prefix . 'digical_speakers', ['event_id' => $id], ['%s']);
        $wpdb->delete($wpdb->prefix . 'digical_titles', ['event_id' => $id], ['%s']);
        $wpdb->delete($wpdb->prefix . 'digical_roles', ['event_id' => $id], ['%s']);
    }

    wp_send_json_success(['message' => count($ids) . ' event(s) deleted successfully']);
});