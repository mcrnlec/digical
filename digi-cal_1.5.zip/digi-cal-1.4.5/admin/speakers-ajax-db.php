<?php
/**
 * DigiCal Speakers AJAX & Database - CLEAN VERSION
 * FILE: digi-cal/admin/speakers-ajax-db.php
 * NO duplicate functions - only original functionality
 */

if (!defined('ABSPATH')) exit;

/**
 * Ensure speakers table exists
 */
function digical_speakers_ensure_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'digical_speakers';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS `$table` (
        `id` varchar(100) NOT NULL PRIMARY KEY,
        `event_id` varchar(100) NOT NULL,
        `title` varchar(50) DEFAULT NULL,
        `first_name` varchar(100) NOT NULL,
        `last_name` varchar(100) NOT NULL,
        `bio` longtext DEFAULT NULL,
        `photo_url` text DEFAULT NULL,
        `roles` json DEFAULT NULL,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        KEY `idx_event_id` (`event_id`),
        KEY `idx_name` (`last_name`, `first_name`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * AJAX: Get all speakers for event
 */
add_action('wp_ajax_digical_get_speakers', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    
    if (!$event_id) {
        wp_send_json_error('Event ID required');
        return;
    }
    
    $table = $wpdb->prefix . 'digical_speakers';
    $speakers = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY last_name ASC, first_name ASC", $event_id),
        ARRAY_A
    );
    
    // Decode roles JSON for each speaker
    if (is_array($speakers)) {
        foreach ($speakers as &$speaker) {
            if (isset($speaker['roles']) && is_string($speaker['roles'])) {
                $speaker['roles'] = json_decode($speaker['roles'], true) ?: [];
            }
        }
    }
    
    wp_send_json_success(['speakers' => is_array($speakers) ? $speakers : []]);
});

/**
 * AJAX: Add speaker (FIXED - matches days pattern)
 */
add_action('wp_ajax_digical_add_speaker', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error(['message' => 'Nonce verification failed'], 403);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
        return;
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : digical_get_active_event_id();
    
    if (!$event_id) {
        wp_send_json_error(['message' => 'No active event']);
        return;
    }
    
    $id = 'speaker_' . substr(md5(uniqid()), 0, 20);
    $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
    $first_name = isset($_POST['first_name']) ? sanitize_text_field($_POST['first_name']) : '';
    $last_name = isset($_POST['last_name']) ? sanitize_text_field($_POST['last_name']) : '';
    $bio = isset($_POST['bio']) ? wp_kses_post($_POST['bio']) : '';
    $photo_id = isset($_POST['photo_id']) ? sanitize_text_field($_POST['photo_id']) : '';
    
    // Get roles - handle both array and comma-separated string
    $roles = [];
    if (isset($_POST['roles'])) {
        if (is_array($_POST['roles'])) {
            $roles = array_map('sanitize_text_field', $_POST['roles']);
        } elseif (is_string($_POST['roles'])) {
            $roles = array_map('trim', explode(',', sanitize_text_field($_POST['roles'])));
        }
    }
    
    if (!$first_name || !$last_name) {
        wp_send_json_error(['message' => 'First name and last name are required']);
        return;
    }
    
    if (empty($roles)) {
        wp_send_json_error(['message' => 'At least one role is required']);
        return;
    }
    
    $table = $wpdb->prefix . 'digical_speakers';
    $photo_url = '';
    if ($photo_id && is_numeric($photo_id)) {
        $photo_url = wp_get_attachment_url($photo_id);
    }
    
    $result = $wpdb->insert(
        $table,
        [
            'id' => $id,
            'event_id' => $event_id,
            'title' => $title,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'bio' => $bio,
            'photo_url' => $photo_url,
            'roles' => json_encode($roles),
        ],
        ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
    );
    
    if ($result === false) {
        wp_send_json_error(['message' => 'Database error: ' . $wpdb->last_error]);
        return;
    }
    
    $speakers = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY last_name ASC, first_name ASC", $event_id),
        ARRAY_A
    );
    
    if (is_array($speakers)) {
        foreach ($speakers as &$speaker) {
            if (isset($speaker['roles']) && is_string($speaker['roles'])) {
                $speaker['roles'] = json_decode($speaker['roles'], true) ?: [];
            }
        }
    }
    
    wp_send_json_success(['speakers' => $speakers, 'message' => 'Speaker added']);
});

/**
 * AJAX: Edit speaker (FIXED - matches days pattern)
 */
add_action('wp_ajax_digical_edit_speaker', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error(['message' => 'Nonce verification failed'], 403);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
        return;
    }
    
    global $wpdb;
    $id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    
    if (!$id || !$event_id) {
        wp_send_json_error(['message' => 'Speaker ID and Event ID required']);
        return;
    }
    
    $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
    $first_name = isset($_POST['first_name']) ? sanitize_text_field($_POST['first_name']) : '';
    $last_name = isset($_POST['last_name']) ? sanitize_text_field($_POST['last_name']) : '';
    $bio = isset($_POST['bio']) ? wp_kses_post($_POST['bio']) : '';
    $photo_id = isset($_POST['photo_id']) ? sanitize_text_field($_POST['photo_id']) : '';
    
    // Get roles
    $roles = [];
    if (isset($_POST['roles'])) {
        if (is_array($_POST['roles'])) {
            $roles = array_map('sanitize_text_field', $_POST['roles']);
        } elseif (is_string($_POST['roles'])) {
            $roles = array_map('trim', explode(',', sanitize_text_field($_POST['roles'])));
        }
    }
    
    if (!$first_name || !$last_name) {
        wp_send_json_error(['message' => 'First name and last name are required']);
        return;
    }
    
    if (empty($roles)) {
        wp_send_json_error(['message' => 'At least one role is required']);
        return;
    }
    
    $table = $wpdb->prefix . 'digical_speakers';
    $photo_url = '';
    if ($photo_id && is_numeric($photo_id)) {
        $photo_url = wp_get_attachment_url($photo_id);
    }
    
    $result = $wpdb->update(
        $table,
        [
            'title' => $title,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'bio' => $bio,
            'photo_url' => $photo_url,
            'roles' => json_encode($roles),
        ],
        ['id' => $id, 'event_id' => $event_id],
        ['%s', '%s', '%s', '%s', '%s', '%s'],
        ['%s', '%s']
    );
    
    if ($result === false) {
        wp_send_json_error(['message' => 'Database error: ' . $wpdb->last_error]);
        return;
    }
    
    $speakers = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY last_name ASC, first_name ASC", $event_id),
        ARRAY_A
    );
    
    if (is_array($speakers)) {
        foreach ($speakers as &$speaker) {
            if (isset($speaker['roles']) && is_string($speaker['roles'])) {
                $speaker['roles'] = json_decode($speaker['roles'], true) ?: [];
            }
        }
    }
    
    wp_send_json_success(['speakers' => $speakers, 'message' => 'Speaker updated']);
});

/**
 * AJAX: Delete speaker (FIXED - matches days pattern)
 */
add_action('wp_ajax_digical_delete_speaker', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error(['message' => 'Nonce verification failed'], 403);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
        return;
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    $id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
    
    if (!$id || !$event_id) {
        wp_send_json_error(['message' => 'Speaker ID and Event ID required']);
        return;
    }
    
    $table = $wpdb->prefix . 'digical_speakers';
    $wpdb->delete($table, ['id' => $id, 'event_id' => $event_id], ['%s', '%s']);
    
    $speakers = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY last_name ASC, first_name ASC", $event_id),
        ARRAY_A
    );
    
    if (is_array($speakers)) {
        foreach ($speakers as &$speaker) {
            if (isset($speaker['roles']) && is_string($speaker['roles'])) {
                $speaker['roles'] = json_decode($speaker['roles'], true) ?: [];
            }
        }
    }
    
    wp_send_json_success(['speakers' => $speakers, 'message' => 'Speaker deleted']);
});

/**
 * AJAX: Bulk delete speakers
 */
add_action('wp_ajax_digical_delete_speakers_bulk', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'digical_nonce')) {
        wp_send_json_error(['message' => 'Nonce verification failed'], 403);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
        return;
    }
    
    global $wpdb;
    $event_id = isset($_POST['event_id']) ? sanitize_text_field($_POST['event_id']) : '';
    $ids = isset($_POST['ids']) ? array_map('sanitize_text_field', (array) $_POST['ids']) : [];
    
    if (!$event_id || empty($ids)) {
        wp_send_json_error(['message' => 'Event ID and speaker IDs required']);
        return;
    }
    
    $table = $wpdb->prefix . 'digical_speakers';
    
    // Delete each speaker
    foreach ($ids as $id) {
        $wpdb->delete($table, ['id' => $id, 'event_id' => $event_id], ['%s', '%s']);
    }
    
    $speakers = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY last_name ASC, first_name ASC", $event_id),
        ARRAY_A
    );
    
    if (is_array($speakers)) {
        foreach ($speakers as &$speaker) {
            if (isset($speaker['roles']) && is_string($speaker['roles'])) {
                $speaker['roles'] = json_decode($speaker['roles'], true) ?: [];
            }
        }
    }
    
    wp_send_json_success(['speakers' => $speakers, 'message' => count($ids) . ' speaker(s) deleted']);
});

/**
 * Get all speakers for active event (helper function for dashboard)
 */
function digical_speakers_all_rows() {
    global $wpdb;
    
    $event_id = digical_get_active_event_id();
    if (!$event_id) {
        return [];
    }
    
    $table = $wpdb->prefix . 'digical_speakers';
    $speakers = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE event_id = %s ORDER BY last_name ASC, first_name ASC", $event_id),
        ARRAY_A
    );
    
    if (is_array($speakers)) {
        foreach ($speakers as &$speaker) {
            if (isset($speaker['roles']) && is_string($speaker['roles'])) {
                $speaker['roles'] = json_decode($speaker['roles'], true) ?: [];
            }
        }
    }
    
    return is_array($speakers) ? $speakers : [];
}