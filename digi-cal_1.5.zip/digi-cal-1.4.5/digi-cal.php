<?php
/*
Plugin Name: DigiCal
Description: Conference calendar with multi-event backend management (DB-backed).
Version: 1.5
Author: DIGIT
Requires at least: 6.8.3
Requires PHP: 8.0
*/

if (!defined('ABSPATH')) exit;

define('DIGICAL_PATH', plugin_dir_path(__FILE__));
define('DIGICAL_URL',  plugin_dir_url(__FILE__));

/* ================================================================
 * LOAD ALL REQUIRED FILES (Order matters!)
 * ================================================================ */

// Event helpers (must load first - has utility functions)
require_once DIGICAL_PATH . 'includes/event-helpers.php';

// AJAX/Database handlers
require_once DIGICAL_PATH . 'admin/days-ajax-db.php';
require_once DIGICAL_PATH . 'admin/venues-ajax-db.php';
require_once DIGICAL_PATH . 'admin/titles-roles-ajax-db.php';
require_once DIGICAL_PATH . 'admin/speakers-ajax-db.php';
require_once DIGICAL_PATH . 'admin/events-ajax-db.php';

// Frontend shortcodes
require_once DIGICAL_PATH . 'includes/shortcode-generator.php';

// GitHub updater
require_once DIGICAL_PATH . 'includes/github-updater.php';

/* ================================================================
 * ACTIVATION HOOK: Ensure all DB tables exist
 * ================================================================ */
register_activation_hook(__FILE__, function () {
    // Events table (NEW - must be first)
    if (function_exists('digical_events_ensure_table')) {
        digical_events_ensure_table();
    }
    
    // Existing tables
    if (function_exists('digical_days_ensure_table')) {
        digical_days_ensure_table();
    }
    if (function_exists('digical_venues_ensure_table')) {
        digical_venues_ensure_table();
    }
    if (function_exists('digical_titles_ensure_table')) {
        digical_titles_ensure_table();
    }
    if (function_exists('digical_roles_ensure_table')) {
        digical_roles_ensure_table();
    }
    if (function_exists('digical_speakers_roles_ensure_table')) {
        digical_speakers_roles_ensure_table();
    }
    if (function_exists('digical_speakers_ensure_table')) {
        digical_speakers_ensure_table();
    }
    if (function_exists('digical_update_speaker_table_schema')) {
        digical_update_speaker_table_schema();
    }
});

/* ================================================================
 * PLUGIN LOAD: Update schemas if needed
 * ================================================================ */
add_action('plugins_loaded', function () {
    if (function_exists('digical_update_speaker_table_schema')) {
        digical_update_speaker_table_schema();
    }
});

/* ================================================================
 * SESSION INITIALIZATION: Start session for event switching
 * ================================================================ */
add_action('init', function () {
    if (!session_id() && !headers_sent()) {
        session_start();
    }
});

/* ================================================================
 * SECTION WRAPPER: Fallback if custom file not present
 * ================================================================ */
function digical_safe_include_section_wrapper() {
    if (!function_exists('digical_section_wrapper')) {
        $file = DIGICAL_PATH . 'admin/section-wrapper.php';
        if (file_exists($file)) {
            include_once $file;
        }
    }
    if (!function_exists('digical_section_wrapper')) {
        function digical_section_wrapper($active, $content_html) {
            echo '<div class="wrap"><h1>DigiCal</h1>' . $content_html . '</div>';
        }
    }
}

/**
 * Format time to HH:MM format
 */
function digical_format_time($time) {
    if (!$time) return '';
    $time = trim($time);
    // If already HH:MM format, return as-is
    if (preg_match('/^\d{1,2}:\d{2}$/', $time)) {
        return $time;
    }
    // If just hour (single digit or double), add :00
    if (preg_match('/^\d{1,2}$/', $time)) {
        return (int)$time . ':00';
    }
    return $time;
}

/* ================================================================
 * ADMIN MENU: Build complete menu structure with multi-events
 * ================================================================ */
add_action('admin_menu', function () {
    global $wpdb;

    // ============================================================
    // TOP-LEVEL: Menu item (redirects to Events via admin_init)
    // ============================================================
    add_menu_page(
        'DigiCal', 'DigiCal', 'manage_options', 'digical',
        function () {
            // Redirect handled by admin_init hook
            echo '<p>Redirecting...</p>';
        },
        'dashicons-calendar-alt', 25
    );

    // ============================================================
    // EVENTS MANAGEMENT (NEW - v1.5) - Only submenu
    // ============================================================
    add_submenu_page(
        'digical', 'Events', 'Events', 'manage_options', 'digical-events',
        function () {
            // Render events page WITHOUT section wrapper (clean, no sidebar)
            echo '<div class="wrap">';
            include DIGICAL_PATH . 'admin/events.php';
            echo '</div>';
        }
    );

    // ============================================================
    // HIDDEN PAGES (not in menu, but keep DigiCal expanded)
    // ================================================================ */
    
    // Hidden Days management page - submenu of DigiCal (hidden label)
    add_submenu_page(
        'digical', '', '', 'manage_options', 'digical-days',
        function () {
            digical_safe_include_section_wrapper();
            ob_start();
            include DIGICAL_PATH . 'admin/days.php';
            $content = ob_get_clean();
            digical_section_wrapper('Days', $content);
        }
    );

    // Hidden Venues management page - submenu of DigiCal (hidden label)
    add_submenu_page(
        'digical', '', '', 'manage_options', 'digical-venues',
        function () {
            digical_safe_include_section_wrapper();
            ob_start();
            include DIGICAL_PATH . 'admin/venues.php';
            $content = ob_get_clean();
            digical_section_wrapper('Venues', $content);
        }
    );

    // Hidden Speakers management page - submenu of DigiCal (hidden label)
    add_submenu_page(
        'digical', '', '', 'manage_options', 'digical-speakers',
        function () {
            digical_safe_include_section_wrapper();
            ob_start();
            include DIGICAL_PATH . 'admin/speakers.php';
            $content = ob_get_clean();
            digical_section_wrapper('Speakers', $content);
        }
    );

    // Hidden Configuration page - submenu of DigiCal (hidden label)
    add_submenu_page(
        'digical', '', '', 'manage_options', 'digical-config',
        function () {
            digical_safe_include_section_wrapper();
            ob_start();
            include DIGICAL_PATH . 'admin/configuration.php';
            $content = ob_get_clean();
            digical_section_wrapper('Configuration', $content);
        }
    );

    // Hidden Dashboard page - submenu of DigiCal (hidden label)
    add_submenu_page(
        'digical', '', '', 'manage_options', 'digical-dashboard',
        function () {
            require_once DIGICAL_PATH . 'admin/days-ajax-db.php';
            require_once DIGICAL_PATH . 'admin/venues-ajax-db.php';
            require_once DIGICAL_PATH . 'admin/speakers-ajax-db.php';
            require_once DIGICAL_PATH . 'admin/dashboard.php';
            digical_safe_include_section_wrapper();
            ob_start();
            ?>
            <style>
            .digical-dashboard {
                background: transparent;
                padding: 0;
                max-width: 100%;
            }
            .digical-quick-actions {
                background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
                padding: 30px;
                border-radius: 12px;
                margin-bottom: 40px;
                box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
            }
            .digical-quick-actions h3 {
                margin: 0 0 20px 0;
                color: white;
                font-size: 18px;
                font-weight: 700;
            }
            .digical-quick-actions-buttons {
                display: flex;
                gap: 16px;
                flex-wrap: wrap;
            }
            .digical-quick-actions-buttons a {
                display: inline-block;
                padding: 12px 24px;
                background: rgba(255, 255, 255, 0.2);
                color: white;
                border: 2px solid rgba(255, 255, 255, 0.4);
                border-radius: 8px;
                text-decoration: none;
                font-weight: 600;
                font-size: 14px;
                transition: all 0.3s ease;
                flex: 1;
                min-width: 180px;
                text-align: center;
            }
            .digical-quick-actions-buttons a:hover {
                background: rgba(255, 255, 255, 0.3);
                border-color: white;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            }
            .digical-stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 20px;
                margin-bottom: 40px;
            }
            .digical-stat-card {
                background: white;
                padding: 24px;
                border-radius: 12px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.06);
                display: flex;
                flex-direction: column;
                transition: all 0.3s ease;
                border-left: 4px solid #2271b1;
            }
            .digical-stat-card:hover {
                box-shadow: 0 8px 16px rgba(0,0,0,0.1);
                transform: translateY(-2px);
            }
            .digical-stat-icon {
                font-size: 32px;
                margin-bottom: 12px;
            }
            .digical-stat-content h3 {
                margin: 0 0 8px 0;
                font-size: 16px;
                color: #2c3e50;
            }
            .digical-stat-number {
                font-size: 28px;
                font-weight: 700;
                color: #2271b1;
                margin: 0 0 8px 0;
            }
            .digical-stat-meta {
                font-size: 12px;
                color: #7f8c8d;
                margin: 0;
            }
            .digical-stat-link {
                color: #2271b1;
                text-decoration: none;
                font-weight: 600;
                margin-top: 12px;
            }
            .digical-upcoming-list {
                background: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            }
            .digical-upcoming-item {
                display: flex;
                align-items: center;
                gap: 20px;
                padding: 16px;
                border-bottom: 1px solid #ecf0f1;
            }
            .digical-upcoming-item:last-child {
                border-bottom: none;
            }
            .digical-empty-state {
                background: white;
                padding: 40px;
                text-align: center;
                border-radius: 8px;
                color: #7f8c8d;
            }
            </style>
            <?php
            digical_render_dashboard();
            $content = ob_get_clean();
            digical_section_wrapper('Dashboard', $content);
        }
    );
});

/* ================================================================
 * ADMIN INIT: Redirect to Events page when clicking DigiCal menu
 * FIX (v1.5.2): Main menu leads to Events for event selection
 * ================================================================ */
add_action('admin_init', function () {
    if (!is_admin()) return;
    $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
    
    // Redirect digical main menu to digical-events (event selection/management)
    if ($page === 'digical') {
        $redirect_url = admin_url('admin.php?page=digical-events');
        wp_redirect($redirect_url);
        exit;
    }
});

/* ================================================================
 * HIDE EMPTY SUBMENU ITEMS via CSS (keep menu expanded)
 * ================================================================ */
add_action('admin_head', function () {
    ?>
    <style>
    /* Hide submenu items with empty labels (but keep menu expanded) */
    #toplevel_page_digical ul li a[href*="digical-days"],
    #toplevel_page_digical ul li a[href*="digical-venues"],
    #toplevel_page_digical ul li a[href*="digical-speakers"],
    #toplevel_page_digical ul li a[href*="digical-config"],
    #toplevel_page_digical ul li a[href*="digical-dashboard"] {
        display: none !important;
    }
    </style>
    <?php
});

/* ================================================================
 * ENQUEUE ADMIN STYLES & SCRIPTS
 * ================================================================ */
add_action('admin_enqueue_scripts', function () {
    $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
    if ($page && ($page === 'digical' || strpos($page, 'digical-') === 0)) {
        // Enqueue CSS
        $css = DIGICAL_PATH . 'assets/css/admin.css';
        if (file_exists($css)) {
            wp_enqueue_style('digical-admin-css', DIGICAL_URL . 'assets/css/admin.css', [], '1.5');
        }
        
        // Enqueue media library for speakers page
        if ($page === 'digical-speakers') {
            wp_enqueue_media();
            wp_enqueue_script('jquery');
        }
        
        // Enqueue JS (if needed for events page)
        if ($page === 'digical-events') {
            wp_enqueue_script('jquery');
        }
    }
});

/* ================================================================
 * VERSION INFORMATION
 * ================================================================ */
define('DIGICAL_VERSION', '1.5');
define('DIGICAL_REQUIRES_WP', '6.0');
define('DIGICAL_REQUIRES_PHP', '8.0');

/* ================================================================
 * DEBUGGING: Log plugin info
 * ================================================================ */
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('DigiCal v' . DIGICAL_VERSION . ' loaded successfully');
}