<?php
/**
 * DigiCal Event Helper Functions (FIXED)
 * 
 * FILE LOCATION: digi-cal/includes/event-helpers.php
 * 
 * COPY THIS ENTIRE FILE AND CREATE IT IN YOUR PLUGIN
 */

if (!defined('ABSPATH')) exit;

/**
 * Generate UUID for event (FIXED - simpler format)
 */
function digical_generate_event_id() {
    // Use WordPress built-in UUID function if available, otherwise generate simple ID
    if (function_exists('wp_generate_uuid4')) {
        $uuid = wp_generate_uuid4();
    } else {
        // Fallback: Generate simple random ID (shorter and more reliable)
        $uuid = 'event_' . substr(md5(uniqid(rand(), true)), 0, 20);
    }
    return $uuid;
}

/**
 * Get all events
 */
function digical_events_all_rows( $status = null ) {
    global $wpdb;
    $table = $wpdb->prefix . 'digical_events';
    
    if ( $status ) {
        $query = $wpdb->prepare(
            "SELECT * FROM $table WHERE status = %s ORDER BY created_at DESC",
            $status
        );
    } else {
        $query = "SELECT * FROM $table ORDER BY created_at DESC";
    }
    
    return $wpdb->get_results( $query, ARRAY_A );
}

/**
 * Get single event by ID
 */
function digical_event_get( $event_id ) {
    global $wpdb;
    $table = $wpdb->prefix . 'digical_events';
    return $wpdb->get_row(
        $wpdb->prepare( "SELECT * FROM $table WHERE id = %s", $event_id ),
        ARRAY_A
    );
}

/**
 * Get active event ID (from session/URL)
 */
function digical_get_active_event_id() {
    // Priority: URL param > session > first published event
    if ( isset( $_GET['event_id'] ) ) {
        return sanitize_text_field( $_GET['event_id'] );
    }
    
    if ( isset( $_SESSION['digical_active_event'] ) ) {
        return $_SESSION['digical_active_event'];
    }
    
    $events = digical_events_all_rows( 'published' );
    return $events ? $events[0]['id'] : null;
}

/**
 * Set active event in session
 */
function digical_set_active_event( $event_id ) {
    if ( ! isset( $_SESSION ) ) {
        session_start();
    }
    $_SESSION['digical_active_event'] = $event_id;
}

/**
 * Copy event with all related data (deep copy) - FIXED
 * 
 * @param string $source_event_id ID of event to copy from
 * @param string $new_name Name for new event
 * @param string $new_slug Optional slug (auto-generated if not provided)
 * @return string|false New event ID on success, false on failure
 */
function digical_event_copy( $source_event_id, $new_name, $new_slug = null ) {
    global $wpdb;
    
    $source = digical_event_get( $source_event_id );
    if ( ! $source ) return false;
    
    $new_id = digical_generate_event_id();
    if ( ! $new_slug ) {
        $new_slug = sanitize_title( $new_name );
        // Add timestamp to make slug unique
        $new_slug = $new_slug . '-' . time();
    }
    
    // 1. Insert new event
    $result = $wpdb->insert(
        $wpdb->prefix . 'digical_events',
        [
            'id'          => $new_id,
            'name'        => $new_name,
            'slug'        => $new_slug,
            'description' => $source['description'],
            'start_date'  => $source['start_date'],
            'end_date'    => $source['end_date'],
            'status'      => 'draft',
            'created_by'  => get_current_user_id(),
        ],
        [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d' ]
    );
    
    if ( ! $result ) {
        error_log('Failed to insert event: ' . $wpdb->last_error);
        return false;
    }
    
    // 2. Copy days
    $days = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}digical_days WHERE event_id = %s",
            $source_event_id
        ),
        ARRAY_A
    );
    foreach ( $days as $day ) {
        $day['id'] = digical_generate_event_id();
        $day['event_id'] = $new_id;
        $wpdb->insert( $wpdb->prefix . 'digical_days', $day );
    }
    
    // 3. Copy venues (with parent-child relationships)
    $venues = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}digical_venues WHERE event_id = %s",
            $source_event_id
        ),
        ARRAY_A
    );
    $venue_map = []; // old_id => new_id mapping
    foreach ( $venues as $venue ) {
        $old_id = $venue['id'];
        $venue['id'] = digical_generate_event_id();
        $venue['event_id'] = $new_id;
        
        // Update parent_id references if this is a sub-venue
        if ( $venue['parent_id'] && isset( $venue_map[ $venue['parent_id'] ] ) ) {
            $venue['parent_id'] = $venue_map[ $venue['parent_id'] ];
        }
        
        $wpdb->insert( $wpdb->prefix . 'digical_venues', $venue );
        $venue_map[ $old_id ] = $venue['id'];
    }
    
    // 4. Copy speakers
    $speakers = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}digical_speakers WHERE event_id = %s",
            $source_event_id
        ),
        ARRAY_A
    );
    $speaker_map = []; // old_id => new_id mapping
    foreach ( $speakers as $speaker ) {
        $old_id = $speaker['id'];
        $speaker['id'] = digical_generate_event_id();
        $speaker['event_id'] = $new_id;
        $wpdb->insert( $wpdb->prefix . 'digical_speakers', $speaker );
        $speaker_map[ $old_id ] = $speaker['id'];
    }
    
    // 5. Copy speaker roles (using speaker_map)
    $roles = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT sr.* FROM {$wpdb->prefix}digical_speakers_roles sr
             JOIN {$wpdb->prefix}digical_speakers s ON sr.speaker_id = s.id
             WHERE s.event_id = %s",
            $source_event_id
        ),
        ARRAY_A
    );
    foreach ( $roles as $role ) {
        $role['id'] = digical_generate_event_id();
        if ( isset( $speaker_map[ $role['speaker_id'] ] ) ) {
            $role['speaker_id'] = $speaker_map[ $role['speaker_id'] ];
        }
        $wpdb->insert( $wpdb->prefix . 'digical_speakers_roles', $role );
    }
    
    // 6. Copy titles
    $titles = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}digical_titles WHERE event_id = %s",
            $source_event_id
        ),
        ARRAY_A
    );
    foreach ( $titles as $title ) {
        $title['id'] = digical_generate_event_id();
        $title['event_id'] = $new_id;
        $wpdb->insert( $wpdb->prefix . 'digical_titles', $title );
    }
    
    // 7. Copy roles
    $role_rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}digical_roles WHERE event_id = %s",
            $source_event_id
        ),
        ARRAY_A
    );
    foreach ( $role_rows as $role_row ) {
        $role_row['id'] = digical_generate_event_id();
        $role_row['event_id'] = $new_id;
        $wpdb->insert( $wpdb->prefix . 'digical_roles', $role_row );
    }
    
    return $new_id;
}

/**
 * Ensure events table exists (for activation hook)
 */
function digical_events_ensure_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'digical_events';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS `$table` (
        `id` varchar(100) NOT NULL PRIMARY KEY COMMENT 'Unique event ID',
        `name` varchar(255) NOT NULL,
        `slug` varchar(255) UNIQUE NOT NULL,
        `description` longtext DEFAULT NULL,
        `start_date` varchar(8) DEFAULT NULL,
        `end_date` varchar(8) DEFAULT NULL,
        `status` enum('draft','published') DEFAULT 'draft',
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        `created_by` bigint(20) DEFAULT NULL,
        KEY `idx_status` (`status`),
        KEY `idx_slug` (`slug`),
        KEY `idx_created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}