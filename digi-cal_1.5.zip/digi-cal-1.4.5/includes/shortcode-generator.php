<?php
/**
 * DigiCal Frontend Shortcodes
 * 
 * FILE LOCATION: digi-cal/includes/shortcode-generator.php
 * 
 * COPY THIS ENTIRE FILE AND CREATE IT IN YOUR PLUGIN
 * 
 * ADD THIS LINE TO digi-cal.php:
 * require_once DIGICAL_PATH . 'includes/shortcode-generator.php';
 * 
 * USAGE:
 * [digical_agenda event_slug="my-event"]
 * [digical_speakers event_slug="my-event"]
 * [digical_venues event_slug="my-event"]
 */

if (!defined('ABSPATH')) exit;

/**
 * Register frontend shortcodes
 */
add_action('init', function() {
    add_shortcode('digical_agenda', 'digical_render_agenda_shortcode');
    add_shortcode('digical_speakers', 'digical_render_speakers_shortcode');
    add_shortcode('digical_venues', 'digical_render_venues_shortcode');
});

/**
 * Render event agenda (days + times)
 * Usage: [digical_agenda event_slug="my-event"]
 */
function digical_render_agenda_shortcode($atts) {
    $atts = shortcode_atts([
        'event_id' => '',
        'event_slug' => '',
    ], $atts);

    global $wpdb;
    
    // Get event
    if ($atts['event_slug']) {
        $event = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}digical_events WHERE slug = %s",
                $atts['event_slug']
            ),
            ARRAY_A
        );
    } else {
        $event = digical_event_get($atts['event_id']);
    }

    if (!$event || $event['status'] !== 'published') {
        return '<p>Event not found or not published.</p>';
    }

    // Get days for this event
    $days = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}digical_days WHERE event_id = %s ORDER BY date ASC",
            $event['id']
        ),
        ARRAY_A
    );

    ob_start();
    ?>
    <div class="digical-agenda" data-event="<?php echo esc_attr($event['id']); ?>">
        <h2><?php echo esc_html($event['name']); ?></h2>
        <?php if ($event['description']): ?>
            <p><?php echo wp_kses_post($event['description']); ?></p>
        <?php endif; ?>

        <div class="digical-days">
            <?php foreach ($days as $day): ?>
                <div class="day-block">
                    <h3><?php echo esc_html($day['day_name'] . ' ' . substr($day['date'], 0, 2) . '.' . substr($day['date'], 2, 2) . '.' . substr($day['date'], 4)); ?></h3>
                    <p><strong>Time:</strong> <?php echo esc_html($day['start_time'] . ' - ' . $day['end_time']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <style>
    .digical-agenda { margin: 20px 0; }
    .digical-days { display: flex; flex-wrap: wrap; gap: 20px; }
    .day-block { 
        flex: 1; 
        min-width: 250px; 
        border: 1px solid #ddd; 
        padding: 15px; 
        border-radius: 5px;
        background: #f9f9f9;
    }
    .day-block h3 { margin-top: 0; }
    </style>

    <?php
    return ob_get_clean();
}

/**
 * Render event speakers
 * Usage: [digical_speakers event_slug="my-event"]
 */
function digical_render_speakers_shortcode($atts) {
    $atts = shortcode_atts([
        'event_id' => '',
        'event_slug' => '',
    ], $atts);

    global $wpdb;
    
    // Get event
    if ($atts['event_slug']) {
        $event = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}digical_events WHERE slug = %s",
                $atts['event_slug']
            ),
            ARRAY_A
        );
    } else {
        $event = digical_event_get($atts['event_id']);
    }

    if (!$event || $event['status'] !== 'published') {
        return '<p>Event not found or not published.</p>';
    }

    $speakers = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}digical_speakers WHERE event_id = %s ORDER BY last_name ASC",
            $event['id']
        ),
        ARRAY_A
    );

    ob_start();
    ?>
    <div class="digical-speakers">
        <h2>Speakers</h2>
        <div class="speakers-grid">
            <?php foreach ($speakers as $speaker): ?>
                <div class="speaker-card">
                    <?php if ($speaker['photo_url']): ?>
                        <img src="<?php echo esc_url($speaker['photo_url']); ?>" alt="<?php echo esc_attr($speaker['first_name'] . ' ' . $speaker['last_name']); ?>">
                    <?php endif; ?>
                    <h3><?php echo esc_html($speaker['title'] . ' ' . $speaker['first_name'] . ' ' . $speaker['last_name']); ?></h3>
                    <?php if ($speaker['bio']): ?>
                        <p><?php echo wp_kses_post($speaker['bio']); ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <style>
    .digical-speakers { margin: 20px 0; }
    .speakers-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }
    .speaker-card {
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 15px;
        text-align: center;
        background: #fff;
    }
    .speaker-card img {
        width: 100%;
        height: auto;
        border-radius: 50%;
        max-width: 150px;
        margin: 0 auto 10px;
        display: block;
    }
    .speaker-card h3 { margin-top: 10px; }
    </style>

    <?php
    return ob_get_clean();
}

/**
 * Render event venues
 * Usage: [digical_venues event_slug="my-event"]
 */
function digical_render_venues_shortcode($atts) {
    $atts = shortcode_atts([
        'event_id' => '',
        'event_slug' => '',
    ], $atts);

    global $wpdb;
    
    // Get event
    if ($atts['event_slug']) {
        $event = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}digical_events WHERE slug = %s",
                $atts['event_slug']
            ),
            ARRAY_A
        );
    } else {
        $event = digical_event_get($atts['event_id']);
    }

    if (!$event || $event['status'] !== 'published') {
        return '<p>Event not found or not published.</p>';
    }

    // Get primary venues
    $primary_venues = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}digical_venues 
             WHERE event_id = %s AND type = 'primary' 
             ORDER BY name ASC",
            $event['id']
        ),
        ARRAY_A
    );

    ob_start();
    ?>
    <div class="digical-venues">
        <h2>Venues</h2>
        <div class="venues-list">
            <?php foreach ($primary_venues as $venue): ?>
                <div class="venue-block">
                    <h3><?php echo esc_html($venue['name']); ?></h3>
                    <?php if ($venue['address']): ?>
                        <p><strong>Address:</strong> <?php echo esc_html($venue['address']); ?></p>
                    <?php endif; ?>

                    <!-- Sub-venues -->
                    <?php
                    $sub_venues = $wpdb->get_results(
                        $wpdb->prepare(
                            "SELECT * FROM {$wpdb->prefix}digical_venues 
                             WHERE parent_id = %s AND event_id = %s 
                             ORDER BY name ASC",
                            $venue['id'],
                            $event['id']
                        ),
                        ARRAY_A
                    );
                    if ($sub_venues):
                    ?>
                        <div class="sub-venues">
                            <p><strong>Rooms:</strong></p>
                            <ul>
                                <?php foreach ($sub_venues as $sub): ?>
                                    <li><?php echo esc_html($sub['name']); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <style>
    .digical-venues { margin: 20px 0; }
    .venues-list { display: grid; gap: 20px; }
    .venue-block {
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 15px;
        background: #f9f9f9;
    }
    .venue-block h3 { margin-top: 0; }
    .sub-venues { margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee; }
    .sub-venues ul { margin: 10px 0; padding-left: 20px; }
    </style>

    <?php
    return ob_get_clean();
}