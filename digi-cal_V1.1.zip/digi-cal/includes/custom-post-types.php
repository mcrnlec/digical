<?php
// Registered in main plugin file's init action for organization.
// See digi-cal.php for registration.

