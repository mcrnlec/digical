<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

/**
 * 1) Get rows safely (use helper if present, or direct DB query)
 */
if (function_exists('digical_days_all_rows')) {
    $rows = digical_days_all_rows();
} else {
    $table = $wpdb->prefix . 'digical_days';
    // Try to query (table may or may not exist; empty result is fine)
    $rows = $wpdb->get_results("
        SELECT id, date, start_time, end_time
        FROM `$table`
        ORDER BY CONCAT(SUBSTR(date,5,4),SUBSTR(date,3,2),SUBSTR(date,1,2)) ASC, start_time ASC
    ", ARRAY_A);
    if (!is_array($rows)) $rows = [];
}

/**
 * 2) Local helpers
 */
function digical_fmt_date_disp_local($d8){
    $d = preg_replace('/\D+/', '', (string)$d8);
    if (preg_match('/^(\d{2})(\d{2})(\d{4})$/', $d, $m)) {
        return "{$m[1]}.{$m[2]}.{$m[3]}";
    }
    return esc_html($d8);
}
function digical_weekday_name_local($d8){
    $d = preg_replace('/\D+/', '', (string)$d8);
    if (!preg_match('/^(\d{2})(\d{2})(\d{4})$/', $d, $m)) return '';
    $ts = strtotime("{$m[3]}-{$m[2]}-{$m[1]} 00:00:00");
    return $ts ? wp_date('l', $ts) : '';
}

$nonce          = wp_create_nonce('digical_nonce');
$ajaxurl        = admin_url('admin-ajax.php');
$day_manage_base= admin_url('admin.php?page=digical-day-');
?>
<style>
.digical-custom-table{border-collapse:collapse;margin-top:10px;font-size:16px;table-layout:auto;width:100%}
.digical-custom-table,.digical-custom-table th,.digical-custom-table td{border:1px solid #0a6ea6}
.digical-custom-table th{background:#0a6ea6;color:#fff;text-align:center;font-weight:600;font-size:16px;border-right:2px solid #fff;padding:12px 20px}
.digical-custom-table th:last-child{border-right:none}
.digical-custom-table td{background:#fff;padding:8px 20px;border-top:1px solid #ddd;vertical-align:middle;font-size:16px;text-align:center}
.digical-custom-table tr:nth-child(even) td{background:#f7f7f7}

.digical-btn-action{background:#1675bb;color:#fff;border:none;border-radius:4px;padding:5px 12px;font-size:14px;margin-right:7px;cursor:pointer;transition:background .2s;display:inline-block}
.digical-btn-action.delete{background:#e53935}
.digical-btn-action:hover{background:#145e90}
.digical-btn-action.delete:hover{background:#b71c1c}

.digical-btn-config{background:#2ecc71 !important;color:#fff !important;border:none;border-radius:4px;padding:5px 12px;font-size:14px;margin-right:7px;cursor:pointer;display:inline-block;text-decoration:none}
.digical-btn-config:hover{background:#27ae60 !important}

.digical-btn-save{background:#1675bb;color:#fff;border:none;border-radius:4px;padding:6px 20px;font-size:16px;cursor:pointer;transition:background .2s;margin-left:8px}
.digical-btn-save:hover{background:#0e5b95}

.digical-checkbox{width:18px;height:18px;cursor:pointer}

.digical-bar{display:flex;align-items:center;gap:10px;margin:12px 0 6px 0}
.digical-bar .bulk-btn{display:none}
.digical-bar .bulk-btn.show{display:inline-block}
.digical-bulk{background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:6px 14px;font-size:14px;cursor:pointer}
.digical-bulk:hover{background:#c0392b}

#day-form input[type="text"]{padding:6px 10px;font-size:16px;margin-right:6px}
input.date-edit{width:110px;font-size:16px;padding:4px 8px;box-sizing:border-box}
input.time-edit{width:65px;font-size:16px;padding:4px 8px;box-sizing:border-box}
</style>

<h1>Manage Days</h1>

<form id="day-form" autocomplete="off" style="margin-bottom:10px;">
  <input type="text" id="day_date" name="day_date" required placeholder="Date (e.g. 01102025)">
  <input type="text" id="start_time" name="start_time" required placeholder="Start Time (e.g. 8)">
  <input type="text" id="end_time" name="end_time" required placeholder="End Time (e.g. 10)">
  <button type="submit" id="save_day_btn" class="digical-btn-save">Save Day</button>
</form>

<div class="digical-bar">
  <button type="button" id="bulk-delete" class="digical-bulk bulk-btn">Delete selected</button>
</div>

<table class="digical-custom-table" id="days-table">
  <thead>
    <tr>
      <th style="width:48px;text-align:center">
        <input type="checkbox" id="chk-all" class="digical-checkbox" aria-label="Select all">
      </th>
      <th>Date</th>
      <th>Day</th>
      <th>Start Time</th>
      <th>End Time</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($rows as $r): ?>
      <tr data-id="<?php echo esc_attr($r['id']); ?>">
        <td><input type="checkbox" class="digical-checkbox row-chk"></td>
        <td><?php echo digical_fmt_date_disp_local($r['date']); ?></td>
        <td><?php echo esc_html(digical_weekday_name_local($r['date'])); ?></td>
        <td><?php echo esc_html($r['start_time']); ?></td>
        <td><?php echo esc_html($r['end_time']); ?></td>
        <td>
          <button type="button" class="digical-btn-action edit">Edit</button>
          <button type="button" class="digical-btn-action delete">Delete</button>
          <a href="<?php echo esc_url($day_manage_base . $r['id']); ?>" class="digical-btn-config">Configure Day</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<script>
document.addEventListener('DOMContentLoaded', function(){
  const ajaxurl   = <?php echo json_encode($ajaxurl); ?>;
  const nonce     = <?php echo json_encode($nonce); ?>;
  const managePre = <?php echo json_encode($day_manage_base); ?>;

  const tbody   = document.querySelector('#days-table tbody');
  const form    = document.getElementById('day-form');
  const bulkBtn = document.getElementById('bulk-delete');
  const chkAll  = document.getElementById('chk-all');

  // Helpers
  const fmtDate = s => String(s).replace(/^(\d{2})(\d{2})(\d{4})$/, '$1.$2.$3');
  const fmtTime = t => {
    const x = String(t).trim();
    if (/^\d{1,2}$/.test(x)) return x.padStart(2,'0') + ':00';
    if (/^\d{1,2}:\d{2}$/.test(x)) { const [h,m]=x.split(':'); return h.padStart(2,'0') + ':' + m; }
    return x;
  };
  function validateDate(ddmmyyyy){
    const clean = String(ddmmyyyy).replace(/\./g,'');
    if (!/^\d{8}$/.test(clean)) return false;
    const d = parseInt(clean.slice(0,2),10);
    const m = parseInt(clean.slice(2,4),10);
    const y = parseInt(clean.slice(4,8),10);
    const dt = new Date(y, m-1, d);
    return dt.getFullYear()===y && (dt.getMonth()+1)===m && dt.getDate()===d;
  }
  function weekdayName(dateStr){
    const p = String(dateStr).split('.');
    const d = new Date(`${p[2]}-${p[1]}-${p[0]}T00:00:00`);
    return isNaN(d) ? '' : d.toLocaleDateString(undefined, { weekday: 'long' });
  }
  const extractDays = j => (j && j.success && (Array.isArray(j.days) ? j.days : (j.data && Array.isArray(j.data.days) ? j.data.days : null)));

  function selectedIDs(){
    return [...tbody.querySelectorAll('.row-chk:checked')].map(ch => ch.closest('tr').getAttribute('data-id'));
  }
  function updateBulkButton(){
    const count = selectedIDs().length;
    bulkBtn.classList.toggle('show', count >= 2);
    const all = tbody.querySelectorAll('.row-chk').length;
    chkAll.checked = (all>0 && count === all);
  }

  function rebuild(days){
    if (!Array.isArray(days)) return;
    const frag = document.createDocumentFragment();
    days.forEach(row=>{
      const tr=document.createElement('tr');
      tr.setAttribute('data-id', row.id);
      const dclean = String(row.date).replace(/\D/g,'');
      const ddisp  = fmtDate(dclean);
      tr.innerHTML = `
        <td><input type="checkbox" class="digical-checkbox row-chk"></td>
        <td>${ddisp}</td>
        <td>${weekdayName(ddisp)}</td>
        <td>${fmtTime(row.start_time)}</td>
        <td>${fmtTime(row.end_time)}</td>
        <td>
          <button type="button" class="digical-btn-action edit">Edit</button>
          <button type="button" class="digical-btn-action delete">Delete</button>
          <a href="${managePre}${row.id}" class="digical-btn-config">Configure Day</a>
        </td>`;
      frag.appendChild(tr);
    });
    tbody.innerHTML = '';
    tbody.appendChild(frag);
    chkAll.checked = false;
    updateBulkButton();

    // Refresh sidebar submenu if present
    const ul = document.getElementById('digical-days-list');
    if (ul) {
      ul.innerHTML = '';
      const sorted = [...days].sort((a,b)=>{
        const ay = String(a.date).slice(4), am = String(a.date).slice(2,4), ad = String(a.date).slice(0,2);
        const by = String(b.date).slice(4), bm = String(b.date).slice(2,4), bd = String(b.date).slice(0,2);
        return (ay+am+ad).localeCompare(by+bm+bd);
      });
      sorted.forEach(d=>{
        const label = fmtDate(String(d.date).replace(/\D/g,''));
        const li = document.createElement('li');
        const a  = document.createElement('a');
        a.className = 'digical-link';
        a.href = managePre + d.id;
        a.textContent = label;
        li.appendChild(a);
        ul.appendChild(li);
      });
    }
  }

  async function post(body){
    try{
      const res = await fetch(ajaxurl, {
        method:'POST',
        credentials:'same-origin',
        headers:{'Content-Type':'application/x-www-form-urlencoded','Cache-Control':'no-store'},
        body:(body instanceof URLSearchParams) ? body.toString() : new URLSearchParams(body).toString()
      });
      const txt = await res.text();
      try { return JSON.parse(txt); } catch(e){ console.warn('Non-JSON response:', txt); return null; }
    }catch(err){ console.error(err); return null; }
  }

  // Select-all / checkbox changes
  chkAll.addEventListener('change', ()=>{
    tbody.querySelectorAll('.row-chk').forEach(ch => ch.checked = chkAll.checked);
    updateBulkButton();
  });
  tbody.addEventListener('change', e=>{
    if (e.target.classList.contains('row-chk')) updateBulkButton();
  });

  // Bulk delete (no confirm)
  bulkBtn.addEventListener('click', ()=>{
    const ids = selectedIDs();
    if (ids.length < 2) return;
    const params = new URLSearchParams();
    params.append('action','digical_db_delete_days');
    params.append('nonce', nonce);
    ids.forEach(id => params.append('ids[]', id));
    post(params).then(j=>{
      const days = extractDays(j);
      if (days) rebuild(days);
      else if (j && j.data && j.data.message) alert(j.data.message);
    });
  });

  // Row actions
  tbody.addEventListener('click', function(e){
    const btn = e.target.closest('button'); if (!btn) return;
    const tr  = btn.closest('tr');
    const id  = tr.getAttribute('data-id');

    if (btn.classList.contains('delete')) {
      post({action:'digical_db_delete_day', id, nonce}).then(j=>{
        const days = extractDays(j);
        if (days) rebuild(days);
        else if (j && j.data && j.data.message) alert(j.data.message);
      });
      return;
    }

    if (btn.classList.contains('edit')) {
      const td = tr.querySelectorAll('td');
      const d  = td[1].textContent.trim();
      const s  = td[3].textContent.trim();
      const e2 = td[4].textContent.trim();
      td[1].innerHTML = `<input class="date-edit" value="${d}">`;
      // Day column (td[2]) will be recomputed on rebuild
      td[3].innerHTML = `<input class="time-edit" value="${s}">`;
      td[4].innerHTML = `<input class="time-edit" value="${e2}">`;
      btn.textContent = 'Save';
      btn.classList.remove('edit');
      btn.classList.add('save');
      return;
    }

    if (btn.classList.contains('save')) {
      const td   = tr.querySelectorAll('td');
      const newD = td[1].querySelector('input').value.replace(/\./g,'');
      const newS = td[3].querySelector('input').value;
      const newE = td[4].querySelector('input').value;

      if (!validateDate(newD)) { alert('Invalid date'); return; }

      post({
        action:'digical_db_edit_day',
        id, nonce,
        day_date:newD,
        start_time:newS,
        end_time:newE
      }).then(j=>{
        const days = extractDays(j);
        if (days) rebuild(days);
        else if (j && j.data && j.data.message) alert(j.data.message);
      });
      return;
    }
  });

  // Create
  form.addEventListener('submit', function(e){
    e.preventDefault();
    if (!validateDate(form.day_date.value)) { alert('Invalid date'); return; }
    post({
      action:'digical_db_add_day',
      nonce,
      day_date: form.day_date.value,
      start_time: form.start_time.value,
      end_time: form.end_time.value
    }).then(j=>{
      const days = extractDays(j);
      if (days) { rebuild(days); form.reset(); form.day_date.focus(); }
      else if (j && j.data && j.data.message) alert(j.data.message);
    });
  });
});
</script>
